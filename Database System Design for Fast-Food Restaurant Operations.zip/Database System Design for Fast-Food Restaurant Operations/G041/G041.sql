-- Drop existing tables if they exist
DROP TABLE customer CASCADE CONSTRAINTS;
DROP TABLE orders CASCADE CONSTRAINTS;
DROP TABLE ordered_item CASCADE CONSTRAINTS;
DROP TABLE item CASCADE CONSTRAINTS;
DROP TABLE receipt CASCADE CONSTRAINTS;
DROP TABLE payment CASCADE CONSTRAINTS;
DROP TABLE transaction CASCADE CONSTRAINTS;
DROP TABLE dine_in CASCADE CONSTRAINTS;
DROP TABLE takeaway CASCADE CONSTRAINTS;
DROP TABLE delivery CASCADE CONSTRAINTS;
DROP TABLE food CASCADE CONSTRAINTS;
DROP TABLE beverage CASCADE CONSTRAINTS;
DROP TABLE dessert CASCADE CONSTRAINTS;
DROP TABLE cash CASCADE CONSTRAINTS;
DROP TABLE card CASCADE CONSTRAINTS;
DROP TABLE ewallet CASCADE CONSTRAINTS;

SET LINESIZE 1000
SET PAGESIZE 1000

-- Customer Table
REM ********************************************************************
REM Create customer table to hold customer information

Prompt ******  Creating customer table ....

CREATE TABLE customer (
    cust_id NUMBER(8) PRIMARY KEY,
    cust_name VARCHAR2(100) NOT NULL,
    cust_address VARCHAR2(100),
    cust_contactnumber VARCHAR2(12) CHECK (REGEXP_LIKE(cust_contactnumber, '^\d{3}-\d{7,8}$')),
    cust_emailaddress VARCHAR2(100)
);

REM ********************************************************************
REM Input Customer Information

Prompt ******  Inserting Customer Information ....

INSERT INTO customer VALUES( 4538,'Walker Robert Smith','No. 1651, Jalan Sentose, 5/2, Taman Bandar Northtown, 56000 Alam Damai, Kuala Lumpur', '012-56813370', 'aWRS565673@gmail.com');
INSERT INTO customer VALUES( 15834,'Er Ni Ru','548A, Lorong Semtaya, Taman Berhani 2, 50508 Amanah Raya Berhad, Kuala Lumpur', '010-56482946', 'ernruiashari@gmail.com');
INSERT INTO customer VALUES( 66837,'Andrew Ng Yi Han','Unit 7-2-1, BLK 1, Apt Desa Tasik, JLN 3B/39, 57000 Desa Tasik, Kuala Lumpur', '015-46354150', 'NgYiHan@gmail.com');
INSERT INTO customer VALUES( 209264,'Hashimoto Yamaji','965, Jalan Singil, Taman Selangori, 50508 Amanah Raya Berhad, Kuala Lumpur', '014-37856971', 'Carmel_Milk_Tree@gmail.com');
INSERT INTO customer VALUES( 827345,'Choong Ming Yee','Level 6,  Jalan Ampang 1, 50450 Eastern Tower, Kuala Lumpur', '018-33115576', '6hei9tF5og@gmail.com');
INSERT INTO customer VALUES( 9113875,'Tajendra A/L Venkatarama','No. 67 Jalam Burnafi, Taman Kenjang Kunir, 51000 Ampat Tin, Kuala Lumpur', '016-85713309', 'tvTvtVTV@gmail.com');
INSERT INTO customer VALUES( 76513369,'Bur Shazana Binti Mohamedarifin','No. 2D, Jalan Sego 5, Taman Prayasudi Meso, Sri Diamanggok, 512000 Anjung Tiara, Kuala Lumpur', '011-11385700', 'BurShazanaBtMi@gmail.com');


-- Item Master Table (Supertype for Food, Beverage, Dessert)
REM ********************************************************************
REM Create item table to hold item list

Prompt ******  Creating item table ....

CREATE TABLE item (
    item_id VARCHAR2(9) PRIMARY KEY CHECK (REGEXP_LIKE(item_id, '^[FBD]\d{1,8}$')),
    item_type VARCHAR2(8) CHECK (item_type IN ('Food', 'Beverage', 'Dessert'))
);

REM ********************************************************************
REM Input Item List

Prompt ******  Inserting Item list ....

INSERT INTO item VALUES( 'B323','Beverage');
INSERT INTO item VALUES( 'B347','Beverage');
INSERT INTO item VALUES( 'B1338','Beverage');
INSERT INTO item VALUES( 'B1376','Beverage');
INSERT INTO item VALUES( 'B1394','Beverage');
INSERT INTO item VALUES( 'B1541','Beverage');
INSERT INTO item VALUES( 'B1582','Beverage');
INSERT INTO item VALUES( 'B1900','Beverage');
INSERT INTO item VALUES( 'B2025','Beverage');
INSERT INTO item VALUES( 'B2171','Beverage');
INSERT INTO item VALUES( 'D193','Dessert');
INSERT INTO item VALUES( 'D206','Dessert');
INSERT INTO item VALUES( 'D237','Dessert');
INSERT INTO item VALUES( 'D311','Dessert');
INSERT INTO item VALUES( 'D323','Dessert');
INSERT INTO item VALUES( 'D343','Dessert');
INSERT INTO item VALUES( 'D750','Dessert');
INSERT INTO item VALUES( 'D1286','Dessert');
INSERT INTO item VALUES( 'D1951','Dessert');
INSERT INTO item VALUES( 'D2020','Dessert');
INSERT INTO item VALUES( 'F301','Food');
INSERT INTO item VALUES( 'F358','Food');
INSERT INTO item VALUES( 'F637','Food');
INSERT INTO item VALUES( 'F785','Food');
INSERT INTO item VALUES( 'F864','Food');
INSERT INTO item VALUES( 'F910','Food');
INSERT INTO item VALUES( 'F1373','Food');
INSERT INTO item VALUES( 'F1383','Food');
INSERT INTO item VALUES( 'F1945','Food');
INSERT INTO item VALUES( 'F1965','Food');


-- Food Table
REM ********************************************************************
REM Create food table to hold food list
REM The item table has a foreign key to this table.

Prompt ******  Creating food table ....

CREATE TABLE food (
    item_id VARCHAR2(9) PRIMARY KEY CHECK (SUBSTR(item_id, 1, 1) = 'F'),
    food_name VARCHAR2(50) NOT NULL,
    food_price DECIMAL(10,2) NOT NULL,
    food_description VARCHAR2(250),
    CONSTRAINT fk_food_item FOREIGN KEY (item_id) REFERENCES item(item_id)
);

REM ********************************************************************
REM Input Food List

Prompt ******  Inserting Food List ....

INSERT INTO food VALUES( 'F637','French Fried Onion Ring','30', 'Delicately sliced onions, deep-fried to a golden crisp — simple, classic and full of crunch');
INSERT INTO food VALUES( 'F785','Garlic Bacon Pasta','55', 'Al dente pasta tossed in a savory garlic-infused sauce with smoky bacon and a touch of cream');
INSERT INTO food VALUES( 'F864','Hong Kong Style Egg Sandwich','45', 'Fluffy scrambled eggs layered in ultra-soft, crustless milk bread for that signature Hong Kong style café bite');
INSERT INTO food VALUES( 'F910','Italian Chopped Salad','35', 'Crisp romaine, salami, provolone, tomatoes and olives tossed in a zesty Italian vinaigrette.');
INSERT INTO food VALUES( 'F1373','Mongolian Beef','90', 'Sliced beef caramelized in a bold soy-garlic sauce, tossed with scallions for a sweet and salty kick');
INSERT INTO food VALUES( 'F1383','Monte Cristo Omelet Sandwich','45', 'Fluffy omelet layered with ham, turkey and melted cheese, sandwiched between slides of French toast');
INSERT INTO food VALUES( 'F1945','Scrambled Eggs with Smoked Trout and Creme Fraiche','75', 'Lightly scrambled eggs with the subtle smokiness of trout, finished with a touch of creme fraiche for added creaminess and sophistication');
INSERT INTO food VALUES( 'F1965','Sweet Potato and Beef Burrito Pie','55', 'A savory, layered pie filled with tender beef, roasted sweet potatoes and all the flavors of a classic burrito cheese, beans and spices');
INSERT INTO food VALUES( 'F301','Chicken fried steak with buttery spring greens','80', 'Southern-fried chicken steak with a golden crust, complemented by delicate spring greens tossed in velvety butter for a refined comfort dish');
INSERT INTO food VALUES( 'F358','Creamy New England Fish Chowder','65', 'Hearty chunks of fresh fish in a velvety cream broth with potatoes and onions — warm, comforting and full of coastal flavor');

-- Beverage Table
REM ********************************************************************
REM Create beverage table to hold beverage list
REM The item table has a foreign key to this table.

Prompt ******  Creating beverage table ....

CREATE TABLE beverage (
    item_id VARCHAR2(9) PRIMARY KEY CHECK (SUBSTR(item_id, 1, 1) = 'B'),
    beverage_name VARCHAR2(50) NOT NULL,
    beverage_price DECIMAL(10,2) NOT NULL,
    beverage_description VARCHAR2(250),
    CONSTRAINT fk_beverage_item FOREIGN KEY (item_id) REFERENCES item(item_id)
);

REM ********************************************************************
REM Input Beverage List

Prompt ******  Inserting Beverage List ....

INSERT INTO beverage VALUES( 'B323','Cappuccino','35', 'A robust espresso blended with steamed milk and topped with thick, creamy foam, offering the ideal balance of rich coffee flavor and smooth texture');
INSERT INTO beverage VALUES( 'B347','Coconut Mojito','66', 'Coconut water, white rum, fresh lime juice and fragrant mint combine in this vibrant, refreshing mojito — an exotic twist on classic favorite');
INSERT INTO beverage VALUES( 'B1338','Macha Latte','35', 'Matcha powder, carefully whisked into steamed milk, offering a smooth, velvety texture with a delicate balance of earthy matcha and creamy milk');
INSERT INTO beverage VALUES( 'B1376','Mango Orange Peach Cream Soda','30', 'A sparkling mix of mango, orange and peach flavors, enhanced by a creamy soda base — perfectly fruity and refreshing with every sip');
INSERT INTO beverage VALUES( 'B1394','Masala Chai Tea','40', 'A traditional Indian tea blend of black tea leaves and aromatic spices like cardamom, cinnamon, cloves and ginger into warm, creamy milk');
INSERT INTO beverage VALUES( 'B1541','Orange Mint Tea','30', 'Sweet, tangy orange blends harmoniously with fresh, cool, fragrant mint leaves and become refreshing aromatic tea');
INSERT INTO beverage VALUES( 'B1582','Oreo Milkshake','43', 'A velvety milkshake made with crushed Oreos, smooth vanilla ice cream and a splash of milk, topped with whipped cream');
INSERT INTO beverage VALUES( 'B1900','Sloe Gin Fizz Cocktail','66', 'Signature deep berry, blush or ruby color, mix with freshly squeezed lemon juice, dark, fruity sloe gin and lightened with soda water');
INSERT INTO beverage VALUES( 'B2025','Tropical Oat and Fruit Yogurt Bowl','35', 'A vibrant mix of silky yogurt, tender oats and jewel-toned tropical fruits');
INSERT INTO beverage VALUES( 'B2171','Ultra-Creamy Avocado Smoothie','33', 'Lusciously blended with ripe avocado,boasts a gorgeous green glow and luxurious mouthfeel');

-- Dessert Table
REM ********************************************************************
REM Create dessert table to hold dessert list
REM The item table has a foreign key to this table.

Prompt ******  Creating dessert table ....

CREATE TABLE dessert (
    item_id VARCHAR2(9) PRIMARY KEY CHECK (SUBSTR(item_id, 1, 1) = 'D'),
    dessert_name VARCHAR2(50) NOT NULL,
    dessert_price DECIMAL(10,2) NOT NULL,
    dessert_description VARCHAR2(250),
    CONSTRAINT fk_dessert_item FOREIGN KEY (item_id) REFERENCES item(item_id)
);

REM ********************************************************************
REM Input Dessert List

Prompt ******  Inserting Dessert List ....

INSERT INTO dessert VALUES( 'D193','Affogato Coffee With Amaretto','60', 'Robust coffee flavor meets smooth vanilla gelato, with subtly sweet depth of Amaretto liqueur');
INSERT INTO dessert VALUES( 'D206','Berry Quinoa Muffin','45', 'Loaded with an assortment of fresh, juicy berries, each muffin offers a delightful burst of fruitiness, complemented by the nutty, hearty texture of quinoa');
INSERT INTO dessert VALUES( 'D237','Black Forest Tiramisu','50', 'A rich twist on the classic tiramisu, featuring luxurious layers fusion of dark chocolate, espresso-soaked ladyfingers, mascarpone cream and tart cherry topping');
INSERT INTO dessert VALUES( 'D311','Classic Buttermilk Waffle','45', 'Golden-brown waffles made with rich buttermilk, offering a pillowy soft, fluffy interior and a slightly crispy exterior — perfect for drizzling with syrup, adding fruit or enjoying as is');
INSERT INTO dessert VALUES( 'D323','Classic Carrot Cake With Cream-Cheese Frosting','45', 'A rich, moist carrot cake filled with warm spices, grated carrots, cinnamon and walnuts, complemented by a luscious, velvety cream-cheese frosting');
INSERT INTO dessert VALUES( 'D343','Chocolate-Zucchini Bran Muffin','45', 'Wholesome balance blend of fiber-rich bran and fresh zucchini, enhanced by the deep richness of chocolate and bursting with gooey chocolate chips for an extra touch of indulgence');
INSERT INTO dessert VALUES( 'D750','Glazed Lemon Loaf','45', 'Made with fresh lemon zest and juice, this tender loaf is topped with a silky, sweet lemon glaze that adds an irresistible citrusy sweetness');
INSERT INTO dessert VALUES( 'D1286','Lemon Ricotta Pikelets With Honey and Berries','45', 'Delicate ricotta pikelets infused with fresh hint of lemon, drizzled with golden honey, and scattered with colorful burst of juicy berries');
INSERT INTO dessert VALUES( 'D1951','Sticky Date Pudding','55', 'Rich and indulgent date pudding drenched in luxurious toffee sauce, offering the perfect balance of softness, moisture, sweetness and warmth in every comforting bite');
INSERT INTO dessert VALUES( 'D2020','Tropical Mini Pavlovas','55', 'Delicate, airy, crispy meringue shell base, topped with a luscious layer of whipped cream and vibrant mix of tropical fruits—sweet, refreshing, and utterly delightful');


-- Main Order Table
REM ********************************************************************
REM Create order table to hold order records
REM The customer table has a foreign key to this table.

Prompt ******  Creating order table ....

CREATE TABLE orders (
    order_id VARCHAR2(17) PRIMARY KEY,
    order_type VARCHAR2(8) CHECK (order_type IN ('Dine-in', 'Takeaway', 'Delivery')),
    order_status VARCHAR2(9) CHECK (order_status IN ('New', 'Proceed', 'Success', 'Finish', 'Terminate')),
    order_date DATE NOT NULL,
    order_time TIMESTAMP NOT NULL,
    cust_id NUMBER(8),
    CONSTRAINT fk_orders_customer FOREIGN KEY (cust_id) REFERENCES customer(cust_id),
    CONSTRAINT chk_order_id_format CHECK (
	REGEXP_LIKE(order_id, '^(DI|TA|DY)\d{8}[npstf]\d{1,6}$')
    )
);

REM ********************************************************************
REM Input Order Records

Prompt ******  Inserting Order Records ....

-- Insert data into Order table

INSERT INTO orders VALUES ('DY25062020n8', 'Delivery', 'New', TO_DATE('25/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('25/06/2020 11:00:00', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DY27062020n11', 'Delivery', 'New', TO_DATE('27/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('27/06/2020 17:43:02', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('TA30062020n10', 'Takeaway', 'New', TO_DATE('30/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('30/06/2020 15:39:27', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DY25062020p8', 'Delivery', 'Proceed', TO_DATE('25/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('25/06/2020 07:05:00', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DI01072020n1', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020p1', 'Dine-in', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DY01072020n1', 'Delivery', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:30:11', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY25062020f8', 'Delivery', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:47:21', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DY25062020s8', 'Delivery', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:47:21', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DI01072020s1', 'Dine-in', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:20:47', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020f1', 'Dine-in', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:35:08', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('TA01072020n1', 'Takeaway', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:10:44', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('TA01072020p1', 'Takeaway', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:20:10', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('DY01072020n2', 'Delivery', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020p2', 'Delivery', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020s2', 'Delivery', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('TA01072020f1', 'Takeaway', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:52:37', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('TA01072020s1', 'Takeaway', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:52:37', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('TA01072020n2', 'Takeaway', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('TA01072020p2', 'Takeaway', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('TA01072020s2', 'Takeaway', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('DY01072020f2', 'Delivery', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:39:53', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('TA30062020p10', 'Takeaway', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:08:59', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DY01072020p1', 'Delivery', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:35:37', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('TA01072020n3', 'Takeaway', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:00:13', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('TA30062020f10', 'Takeaway', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:11:47', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('TA30062020s10', 'Takeaway', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:11:47', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DI01072020p4', 'Dine-in', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020n4', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('TA01072020f2', 'Takeaway', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:37:27', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('DI01072020s4', 'Dine-in', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:47:09', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020f4', 'Dine-in', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:00:54', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020n2', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:05:32', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DI01072020n3', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:07:39', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('TA01072020p3', 'Takeaway', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:12:58', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('DY01072020f1', 'Delivery', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:26:00', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020s1', 'Delivery', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:26:00', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DI01072020p5', 'Dine-in', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 76513369);
INSERT INTO orders VALUES ('DI01072020s5', 'Dine-in', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 76513369);
INSERT INTO orders VALUES ('DI01072020n5', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 76513369);
INSERT INTO orders VALUES ('TA01072020f3', 'Takeaway', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:31:03', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('TA01072020s3', 'Takeaway', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:31:03', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('DI01072020p3', 'Dine-in', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DI01072020s3', 'Dine-in', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020p3', 'Delivery', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020s3', 'Delivery', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020n3', 'Delivery', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020n4', 'Delivery', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:42:19', 'DD/MM/YYYY HH24:MI:SS'), 209264);
INSERT INTO orders VALUES ('DY27062020p11', 'Delivery', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:04:26', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('TA01072020n4', 'Takeaway', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:26:56', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('DI01072020f3', 'Dine-in', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:38:50', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DI01072020p6', 'Dine-in', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DI01072020n6', 'Dine-in', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('DY27062020f11', 'Delivery', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:18:47', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('DY27062020s11', 'Delivery', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:18:47', 'DD/MM/YYYY HH24:MI:SS'), 15834);
INSERT INTO orders VALUES ('TA01072020n5', 'Takeaway', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:48:37', 'DD/MM/YYYY HH24:MI:SS'), 66837);
INSERT INTO orders VALUES ('DY01072020f3', 'Delivery', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:02:22', 'DD/MM/YYYY HH24:MI:SS'), 4538);
INSERT INTO orders VALUES ('DY01072020n5', 'Delivery', 'New', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:13:45', 'DD/MM/YYYY HH24:MI:SS'), 209264);
INSERT INTO orders VALUES ('DI01072020s6', 'Dine-in', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:25:42', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('TA01072020p4', 'Takeaway', 'Proceed', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:30:16', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('DI01072020f6', 'Dine-in', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:46:21', 'DD/MM/YYYY HH24:MI:SS'), 827345);
INSERT INTO orders VALUES ('TA01072020f4', 'Takeaway', 'Finish', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:27:28', 'DD/MM/YYYY HH24:MI:SS'), 9113875);
INSERT INTO orders VALUES ('TA01072020s4', 'Takeaway', 'Success', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:27:28', 'DD/MM/YYYY HH24:MI:SS'), 9113875);

-- Dine-In Orders (Subtype of Order)
REM ********************************************************************
REM Create dine_in table to hold dine_in records 
REM The order has a foreign key to this table.

Prompt ******  Creating dine_in table ....

CREATE TABLE dine_in (
    order_id VARCHAR2(17) PRIMARY KEY CHECK (SUBSTR(order_id, 1, 2) = 'DI'),
    table_num NUMBER(3) CHECK (table_num BETWEEN 1 AND 999),
    dine_in_date DATE,
    dine_in_time TIMESTAMP,
    CONSTRAINT fk_dinein_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

REM ********************************************************************
REM Input Dine-In Records

Prompt ******  Inserting dine_in Records....

INSERT INTO dine_in VALUES ('DI01072020n1', 1, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO dine_in VALUES ('DI01072020n2', 3, TO_DATE('05/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('05/07/2020 13:30:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO dine_in VALUES ('DI01072020n3', 2, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:15:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO dine_in VALUES ('DI01072020n4', 1, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO dine_in VALUES ('DI01072020n5', 10, TO_DATE('13/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('13/07/2020 14:30:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO dine_in VALUES ('DI01072020n6', 1, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'));

-- Takeaway Orders (Subtype of Order)
REM ********************************************************************
REM Create takeaway table to hold takeaway records
REM The order table has a foreign key to this table.

Prompt ******  Creating takeaway table ....

CREATE TABLE takeaway (
    order_id VARCHAR2(17) PRIMARY KEY CHECK (SUBSTR(order_id, 1, 2) = 'TA'),
    pickup_date DATE,
    pickup_time TIMESTAMP,
    CONSTRAINT fk_takeaway_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

REM ********************************************************************
REM Input Takeaway Records

Prompt ******  Inserting Takaway Records....

INSERT INTO takeaway VALUES ('TA30062020n10', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:00:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO takeaway VALUES ('TA01072020n1', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:30:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO takeaway VALUES ('TA01072020n2', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:35:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO takeaway VALUES ('TA01072020n3', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:00:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO takeaway VALUES ('TA01072020n4', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:05:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO takeaway VALUES ('TA01072020n5', TO_DATE('02/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('02/07/2020 16:00:00', 'DD/MM/YYYY HH24:MI:SS'));

-- Delivery Orders (Subtype of Order)
REM ********************************************************************
REM Create delivery table to hold delivery records
REM The order table has a foreign key to this table.

Prompt ******  Creating beverage table ....

CREATE TABLE delivery (
    order_id VARCHAR2(17) PRIMARY KEY CHECK (SUBSTR(order_id, 1, 2) = 'DY'),
    delivery_address VARCHAR2(100),
    delivery_contact VARCHAR2(12) CHECK (REGEXP_LIKE(delivery_contact, '^\d{3}-\d{7,8}$')),
    delivery_date DATE,
    delivery_time TIMESTAMP,
    CONSTRAINT fk_delivery_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

REM ********************************************************************
REM Input Delivery Records

Prompt ******  Inserting Beverage Record....

INSERT INTO delivery VALUES ('DY25062020n8', '548A, Lorong Semtaya, Taman Berhani 2, 50508 Amanah Raya Berhad, Kuala Lumpur', '010-56482946', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:00:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY27062020n11', '548A, Lorong Semtaya, Taman Berhani 2, 50508 Amanah Raya Berhad, Kuala Lumpur', '010-56482946', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:00:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY01072020n1', 'No. 1651, Jalan Sentose, 5/2, Taman Bandar Northtown, 56000 Alam Damai, Kuala Lumpur', '012-56813370', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:30:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY01072020n2', 'No. 56, Jalan Yangsa, 1/1, Taman Lailzu, 51000 Ampat Tin, Kuala Lumpur', '012-63144967', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:45:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY01072020n3', 'No. 56, Jalan Yangsa, 1/1, Taman Lailzu, 51000 Ampat Tin, Kuala Lumpur', '012-63144967', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:15:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY01072020n4', '8, Jalan Bujonh, Taman Gelonggong, 53100 Alang Sedayu Resort, Kuala Lumpur', '014-37856971', TO_DATE('15/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('15/07/2020 19:45:00', 'DD/MM/YYYY HH24:MI:SS'));
INSERT INTO delivery VALUES ('DY01072020n5', '965, Jalan Singil, Taman Selangori, 50508 Amanah Raya Berhad, Kuala Lumpur', '013-66846437', TO_DATE('06/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('06/07/2020 21:30:00', 'DD/MM/YYYY HH24:MI:SS'));


-- Ordered Items (Junction Table)
REM ********************************************************************
REM Create ordered_item table to hold ordered_item records
REM The order and item table has a foreign key to this table.

Prompt ******  Creating ordered_item table ....

CREATE TABLE ordered_item (
    order_id VARCHAR2(17),
    item_id VARCHAR2(9),
    quantity NUMBER(2) NOT NULL CHECK (quantity BETWEEN 1 AND 99),
    PRIMARY KEY (order_id, item_id),
    CONSTRAINT fk_oi_order FOREIGN KEY (order_id) REFERENCES orders(order_id),
    CONSTRAINT fk_oi_item FOREIGN KEY (item_id) REFERENCES item(item_id)
);

REM ********************************************************************
REM Input Ordered Item Records

Prompt ******  Inserting Ordered Item Record ....

INSERT INTO ordered_item VALUES( 'DY25062020n8','D1286','3');
INSERT INTO ordered_item VALUES( 'DY27062020n11','B347','1');
INSERT INTO ordered_item VALUES( 'DY27062020n11','B1900','1');
INSERT INTO ordered_item VALUES( 'DY27062020n11','F785','1');
INSERT INTO ordered_item VALUES( 'DY27062020n11','F1945','1');
INSERT INTO ordered_item VALUES( 'TA30062020n10','B2025','1');
INSERT INTO ordered_item VALUES( 'TA30062020n10','B2171','1');
INSERT INTO ordered_item VALUES( 'DI01072020n1','B323','1');
INSERT INTO ordered_item VALUES( 'DI01072020n1','D237','1');
INSERT INTO ordered_item VALUES( 'DI01072020n1','F864','2');
INSERT INTO ordered_item VALUES( 'DY01072020n1','B1582','2');
INSERT INTO ordered_item VALUES( 'DY01072020n1','B2171','1');
INSERT INTO ordered_item VALUES( 'DY01072020n1','F1965','3');
INSERT INTO ordered_item VALUES( 'TA01072020n1','B2025','1');
INSERT INTO ordered_item VALUES( 'TA01072020n1','D206','1');
INSERT INTO ordered_item VALUES( 'TA01072020n1','D343','1');
INSERT INTO ordered_item VALUES( 'DY01072020n2','F358','5');
INSERT INTO ordered_item VALUES( 'DY01072020n2','F637','5');
INSERT INTO ordered_item VALUES( 'TA01072020n2','B1376','1');
INSERT INTO ordered_item VALUES( 'TA01072020n2','D1951','1');
INSERT INTO ordered_item VALUES( 'TA01072020n2','F301','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','B347','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','B1394','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','D323','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','D750','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','F785','1');
INSERT INTO ordered_item VALUES( 'TA01072020n3','F910','1');
INSERT INTO ordered_item VALUES( 'DI01072020n4','B1541','1');
INSERT INTO ordered_item VALUES( 'DI01072020n4','D2020','1');
INSERT INTO ordered_item VALUES( 'DI01072020n4','F1965','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','B347','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','B1338','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','B2171','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','D311','2');
INSERT INTO ordered_item VALUES( 'DI01072020n2','F301','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','F358','1');
INSERT INTO ordered_item VALUES( 'DI01072020n2','F1945','1');
INSERT INTO ordered_item VALUES( 'DI01072020n3','B347','2');
INSERT INTO ordered_item VALUES( 'DI01072020n3','D237','1');
INSERT INTO ordered_item VALUES( 'DI01072020n3','D1286','1');
INSERT INTO ordered_item VALUES( 'DI01072020n3','F1945','2');
INSERT INTO ordered_item VALUES( 'DI01072020n5','B1376','1');
INSERT INTO ordered_item VALUES( 'DI01072020n5','B1394','1');
INSERT INTO ordered_item VALUES( 'DI01072020n5','B1900','6');
INSERT INTO ordered_item VALUES( 'DI01072020n5','B2171','1');
INSERT INTO ordered_item VALUES( 'DI01072020n5','D193','4');
INSERT INTO ordered_item VALUES( 'DI01072020n5','D237','2');
INSERT INTO ordered_item VALUES( 'DI01072020n5','D1951','1');
INSERT INTO ordered_item VALUES( 'DI01072020n5','D2020','3');
INSERT INTO ordered_item VALUES( 'DI01072020n5','F358','3');
INSERT INTO ordered_item VALUES( 'DI01072020n5','F637','5');
INSERT INTO ordered_item VALUES( 'DI01072020n5','F910','2');
INSERT INTO ordered_item VALUES( 'DI01072020n5','F1373','10');
INSERT INTO ordered_item VALUES( 'DY01072020n3','B323','1');
INSERT INTO ordered_item VALUES( 'DY01072020n3','B347','1');
INSERT INTO ordered_item VALUES( 'DY01072020n3','B1338','1');
INSERT INTO ordered_item VALUES( 'DY01072020n3','B1394','1');
INSERT INTO ordered_item VALUES( 'DY01072020n3','B1582','1');
INSERT INTO ordered_item VALUES( 'DY01072020n4','F864','1');
INSERT INTO ordered_item VALUES( 'DY01072020n4','F1383','1');
INSERT INTO ordered_item VALUES( 'TA01072020n4','D311','1');
INSERT INTO ordered_item VALUES( 'TA01072020n4','D323','1');
INSERT INTO ordered_item VALUES( 'TA01072020n4','D750','1');
INSERT INTO ordered_item VALUES( 'DI01072020n6','B1376','1');
INSERT INTO ordered_item VALUES( 'DI01072020n6','D1286','1');
INSERT INTO ordered_item VALUES( 'DI01072020n6','F1965','1');
INSERT INTO ordered_item VALUES( 'TA01072020n5','B323','2');
INSERT INTO ordered_item VALUES( 'TA01072020n5','D193','2');
INSERT INTO ordered_item VALUES( 'DY01072020n5','F301','1');
INSERT INTO ordered_item VALUES( 'DY01072020n5','F785','1');
INSERT INTO ordered_item VALUES( 'DY01072020n5','F1373','3');
INSERT INTO ordered_item VALUES( 'DY01072020n5','F1945','1');

-- Transaction Table

REM ********************************************************************
REM Create transaction table to hold transaction records
REM The order table has a foreign key to this table.

Prompt ******  Creating transaction table ....

CREATE TABLE transaction (
    transaction_id VARCHAR2(10) PRIMARY KEY CHECK (REGEXP_LIKE(transaction_id, '^(pr|pd|cp|tm)\d{1,8}$')),
    total_before DECIMAL(10,2) NOT NULL,
    discount DECIMAL(5,2),
    tax DECIMAL(5,2) NOT NULL,
    total_after DECIMAL(10,2) NOT NULL,
    transaction_status VARCHAR2(9) CHECK (transaction_status IN ('Process', 'Pending', 'Complete', 'Terminate')),
    transaction_date DATE NOT NULL,
    transaction_time TIMESTAMP NOT NULL,
    order_id VARCHAR2(17),
    CONSTRAINT fk_transaction_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

REM ********************************************************************
REM Input Transaction Records

Prompt ******  Inserting Transaction Records ....

INSERT INTO transaction VALUES ('pr1', 135.00, 0.00, 10.00, 148.50, 'Process', TO_DATE('25/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('25/06/2020 11:00:00', 'DD/MM/YYYY HH24:MI:SS'), 'DY25062020n8');
INSERT INTO transaction VALUES ('pr2', 262.00, 3.00, 10.00, 280.35, 'Process', TO_DATE('27/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('27/06/2020 17:43:02', 'DD/MM/YYYY HH24:MI:SS'), 'DY27062020n11');
INSERT INTO transaction VALUES ('pr3', 68.00, 0.00, 7.00, 72.75, 'Process', TO_DATE('30/06/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('30/06/2020 15:39:27', 'DD/MM/YYYY HH24:MI:SS'), 'TA30062020n10');
INSERT INTO transaction VALUES ('pd1', 135.00, 0.00, 10.00, 148.50, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:05:00', 'DD/MM/YYYY HH24:MI:SS'), 'DY25062020p8');
INSERT INTO transaction VALUES ('pr4', 175.00, 5.00, 8.00, 180.25, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n1');
INSERT INTO transaction VALUES ('pd2', 175.00, 5.00, 8.00, 180.25, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020p1');
INSERT INTO transaction VALUES ('pr5', 284.00, 7.00, 10.00, 292.50, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:30:11', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020n1');
INSERT INTO transaction VALUES ('cp1', 135.00, 0.00, 10.00, 148.50, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:47:21', 'DD/MM/YYYY HH24:MI:SS'), 'DY25062020s8');
INSERT INTO transaction VALUES ('cp2', 175.00, 5.00, 8.00, 180.25, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:20:47', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020s1');
INSERT INTO transaction VALUES ('pr6', 125.00, 3.00, 7.00, 130.00, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:10:44', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020n1');
INSERT INTO transaction VALUES ('pd3', 125.00, 3.00, 7.00, 130.00, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:20:10', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020p1');
INSERT INTO transaction VALUES ('pr7', 475.00, 10.00, 10.00, 475.00, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020n2');
INSERT INTO transaction VALUES ('pd4', 475.00, 10.00, 10.00, 475.00, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020p2');
INSERT INTO transaction VALUES ('cp3', 475.00, 10.00, 10.00, 475.00, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020s2');
INSERT INTO transaction VALUES ('cp4', 125.00, 3.00, 7.00, 130.00, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:52:37', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020s1');
INSERT INTO transaction VALUES ('pr8', 165.00, 2.00, 7.00, 173.25, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020n2');
INSERT INTO transaction VALUES ('pd5', 165.00, 2.00, 7.00, 173.25, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020p2');
INSERT INTO transaction VALUES ('cp5', 165.00, 2.00, 7.00, 173.25, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020s2');
INSERT INTO transaction VALUES ('pd6', 68.00, 0.00, 7.00, 72.75, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:08:59', 'DD/MM/YYYY HH24:MI:SS'), 'TA30062020p10');
INSERT INTO transaction VALUES ('pd7', 284.00, 7.00, 10.00, 292.50, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:35:37', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020p1');
INSERT INTO transaction VALUES ('pr9', 286.00, 7.00, 7.00, 286.00, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:00:13', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020n3');
INSERT INTO transaction VALUES ('cp6', 68.00, 0.00, 7.00, 72.75, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:11:47', 'DD/MM/YYYY HH24:MI:SS'), 'TA30062020s10');
INSERT INTO transaction VALUES ('pr10', 140.00, 0.00, 8.00, 151.20, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n4');
INSERT INTO transaction VALUES ('pd8', 140.00, 0.00, 8.00, 151.20, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020p4');
INSERT INTO transaction VALUES ('cp7', 140.00, 0.00, 8.00, 151.20, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:47:09', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020s4');
INSERT INTO transaction VALUES ('pr11', 445.00, 9.00, 8.00, 440.55, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:05:32', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n2');
INSERT INTO transaction VALUES ('pr12', 377.00, 8.00, 8.00, 377.00, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:07:39', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n3');
INSERT INTO transaction VALUES ('pd9', 286.00, 7.00, 7.00, 286.00, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:12:58', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020p3');
INSERT INTO transaction VALUES ('cp8', 284.00, 7.00, 10.00, 292.50, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:26:00', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020s1');
INSERT INTO transaction VALUES ('pr13', 2374.00, 15.00, 8.00, 2207.80, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n5');
INSERT INTO transaction VALUES ('pd10', 2374.00, 15.00, 8.00, 2207.80, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020p5');
INSERT INTO transaction VALUES ('cp9', 2374.00, 15.00, 8.00, 2207.80, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020s5');
INSERT INTO transaction VALUES ('cp10', 286.00, 7.00, 7.00, 286.00, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:31:03', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020s3');
INSERT INTO transaction VALUES ('pd11', 377.00, 8.00, 8.00, 377.00, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020p3');
INSERT INTO transaction VALUES ('cp11', 377.00, 8.00, 8.00, 377.00, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020s3');
INSERT INTO transaction VALUES ('pr14', 219.00, 5.00, 10.00, 229.95, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020n3');
INSERT INTO transaction VALUES ('pd12', 219.00, 5.00, 10.00, 229.95, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020p3');
INSERT INTO transaction VALUES ('cp12', 219.00, 5.00, 10.00, 229.95, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020s3');
INSERT INTO transaction VALUES ('pr15', 90.00, 0.00, 10.00, 99.00, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:42:19', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020n4');
INSERT INTO transaction VALUES ('pd13', 262.00, 3.00, 10.00, 280.35, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:04:26', 'DD/MM/YYYY HH24:MI:SS'), 'DY27062020p11');
INSERT INTO transaction VALUES ('pr16', 135.00, 0.00, 7.00, 144.45, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:26:56', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020n4');
INSERT INTO transaction VALUES ('pr17', 130.00, 0.00, 8.00, 140.40, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020n6');
INSERT INTO transaction VALUES ('pd14', 130.00, 0.00, 8.00, 140.40, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020p6');
INSERT INTO transaction VALUES ('cp13', 262.00, 3.00, 10.00, 280.35, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:18:47', 'DD/MM/YYYY HH24:MI:SS'), 'DY27062020s11');
INSERT INTO transaction VALUES ('pr18', 190.00, 2.00, 7.00, 199.50, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:48:37', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020n5');
INSERT INTO transaction VALUES ('pr19', 480.00, 9.00, 10.00, 484.80, 'Process', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:13:45', 'DD/MM/YYYY HH24:MI:SS'), 'DY01072020n5');
INSERT INTO transaction VALUES ('cp14', 130.00, 0.00, 8.00, 140.40, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:25:42', 'DD/MM/YYYY HH24:MI:SS'), 'DI01072020s6');
INSERT INTO transaction VALUES ('pd15', 135.00, 0.00, 7.00, 144.45, 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:30:16', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020p4');
INSERT INTO transaction VALUES ('cp15', 135.00, 0.00, 7.00, 144.45, 'Complete', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:27:28', 'DD/MM/YYYY HH24:MI:SS'), 'TA01072020s4');

-- Receipt Table
REM ********************************************************************
REM Create receipt table to hold receipt records
REM The customer and transaction table has a foreign key to this table.

Prompt ******  Creating receipt table ....

CREATE TABLE receipt (
    receipt_id NUMBER(8) PRIMARY KEY,
    receipt_date DATE NOT NULL,
    receipt_time TIMESTAMP NOT NULL,
    cust_id NUMBER(8),
    transaction_id VARCHAR2(10),
    CONSTRAINT fk_receipt_customer FOREIGN KEY (cust_id) REFERENCES customer(cust_id),
    CONSTRAINT fk_receipt_transaction FOREIGN KEY (transaction_id) REFERENCES transaction(transaction_id)
);

REM ********************************************************************
REM Input Receipt Records

Prompt ******  Inserting Receipt Records....

INSERT INTO receipt VALUES (1, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:47:21', 'DD/MM/YYYY HH24:MI:SS'), 15834, 'cp1');
INSERT INTO receipt VALUES (2, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:20:47', 'DD/MM/YYYY HH24:MI:SS'), 827345, 'cp2');
INSERT INTO receipt VALUES (3, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 4538, 'cp3');
INSERT INTO receipt VALUES (4, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:52:37', 'DD/MM/YYYY HH24:MI:SS'), 66837, 'cp4');
INSERT INTO receipt VALUES (5, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 66837, 'cp5');
INSERT INTO receipt VALUES (6, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:11:47', 'DD/MM/YYYY HH24:MI:SS'), 15834, 'cp6');
INSERT INTO receipt VALUES (7, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:47:09', 'DD/MM/YYYY HH24:MI:SS'), 827345, 'cp7');
INSERT INTO receipt VALUES (8, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:26:00', 'DD/MM/YYYY HH24:MI:SS'), 4538, 'cp8');
INSERT INTO receipt VALUES (9, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 76513369, 'cp9');
INSERT INTO receipt VALUES (10, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:31:03', 'DD/MM/YYYY HH24:MI:SS'), 9113875, 'cp10');
INSERT INTO receipt VALUES (11, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 4538, 'cp11');
INSERT INTO receipt VALUES (12, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 4538, 'cp12');
INSERT INTO receipt VALUES (13, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:18:47', 'DD/MM/YYYY HH24:MI:SS'), 15834, 'cp13');
INSERT INTO receipt VALUES (14, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:25:42', 'DD/MM/YYYY HH24:MI:SS'), 827345, 'cp14');
INSERT INTO receipt VALUES (15, TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:27:28', 'DD/MM/YYYY HH24:MI:SS'), 9113875, 'cp15');

-- Payment Master Table (Supertype for Cash, Card, E-Wallet)
REM ********************************************************************
REM Create payment table to hold payment records
REM The transaction table has a foreign key to this table.

Prompt ******  Creating payment table ....


CREATE TABLE payment (
    payment_id VARCHAR2(11) PRIMARY KEY CHECK (REGEXP_LIKE(payment_id, '^(CH|CR|EW)[psf]\d{1,8}$')),
    payment_method VARCHAR2(8) CHECK (payment_method IN ('Cash', 'Card', 'E-Wallet')),
    payment_status VARCHAR2(10) CHECK (payment_status IN ('Pending', 'Successful', 'Fail')),
    payment_date DATE NOT NULL,
    payment_time TIMESTAMP NOT NULL,
    transaction_id VARCHAR2(10),
    CONSTRAINT fk_payment_transaction FOREIGN KEY (transaction_id) REFERENCES transaction(transaction_id)
);

REM ********************************************************************
REM Input Payment Records

Prompt ******  Inserting Payment Records ....

INSERT INTO payment VALUES ('CRp1','Card', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:05:00', 'DD/MM/YYYY HH24:MI:SS'), 'pd1');
INSERT INTO payment VALUES ('CHp1','Cash', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:20:47', 'DD/MM/YYYY HH24:MI:SS'), 'pd2');
INSERT INTO payment VALUES ('CRs1','Card', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 07:47:21', 'DD/MM/YYYY HH24:MI:SS'), 'cp1');
INSERT INTO payment VALUES ('CHs1','Cash', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 08:20:47', 'DD/MM/YYYY HH24:MI:SS'), 'cp2');
INSERT INTO payment VALUES ('EWp1','E-Wallet', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:20:10', 'DD/MM/YYYY HH24:MI:SS'), 'pd3');
INSERT INTO payment VALUES ('EWs1','E-Wallet', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 'cp3');
INSERT INTO payment VALUES ('EWp2','E-Wallet', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 09:31:48', 'DD/MM/YYYY HH24:MI:SS'), 'pd4');
INSERT INTO payment VALUES ('EWs2','E-Wallet', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 10:52:37', 'DD/MM/YYYY HH24:MI:SS'), 'cp4');
INSERT INTO payment VALUES ('CHs2','Cash', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 'cp5');
INSERT INTO payment VALUES ('CHp2','Cash', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 11:19:36', 'DD/MM/YYYY HH24:MI:SS'), 'pd5');
INSERT INTO payment VALUES ('CRp2','Card', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:08:59', 'DD/MM/YYYY HH24:MI:SS'), 'pd6');
INSERT INTO payment VALUES ('EWp3','E-Wallet', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 12:35:37', 'DD/MM/YYYY HH24:MI:SS'), 'pd7');
INSERT INTO payment VALUES ('CRs2','Card', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:11:47', 'DD/MM/YYYY HH24:MI:SS'), 'cp6');
INSERT INTO payment VALUES ('CHp3','Cash', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:15:23', 'DD/MM/YYYY HH24:MI:SS'), 'pd8');
INSERT INTO payment VALUES ('EWs3','E-Wallet', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 13:47:09', 'DD/MM/YYYY HH24:MI:SS'), 'cp7');
INSERT INTO payment VALUES ('EWp4','E-Wallet', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:12:58', 'DD/MM/YYYY HH24:MI:SS'), 'pd9');
INSERT INTO payment VALUES ('CHs3','Cash', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 14:26:00', 'DD/MM/YYYY HH24:MI:SS'), 'cp8');
INSERT INTO payment VALUES ('EWs4','E-Wallet', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 'cp9');
INSERT INTO payment VALUES ('CRp3','Card', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:01:10', 'DD/MM/YYYY HH24:MI:SS'), 'pd10');
INSERT INTO payment VALUES ('CRs3','Card', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 15:31:03', 'DD/MM/YYYY HH24:MI:SS'), 'cp10');
INSERT INTO payment VALUES ('CRs4','Card', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 'cp11');
INSERT INTO payment VALUES ('CRp4','Card', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 16:16:00', 'DD/MM/YYYY HH24:MI:SS'), 'pd11');
INSERT INTO payment VALUES ('CRs5','Card', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 'cp12');
INSERT INTO payment VALUES ('CRp5','Card', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 17:08:31', 'DD/MM/YYYY HH24:MI:SS'), 'pd12');
INSERT INTO payment VALUES ('CHp4','Cash', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:04:26', 'DD/MM/YYYY HH24:MI:SS'), 'pd13');
INSERT INTO payment VALUES ('EWp5','E-Wallet', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 18:55:31', 'DD/MM/YYYY HH24:MI:SS'), 'pd14');
INSERT INTO payment VALUES ('CHs4','Cash', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 19:18:47', 'DD/MM/YYYY HH24:MI:SS'), 'cp13');
INSERT INTO payment VALUES ('EWs5','E-Wallet', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:25:42', 'DD/MM/YYYY HH24:MI:SS'), 'cp14');
INSERT INTO payment VALUES ('CHp5','Cash', 'Pending', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 20:30:16', 'DD/MM/YYYY HH24:MI:SS'), 'pd15');
INSERT INTO payment VALUES ('CHs5','Cash', 'Successful', TO_DATE('01/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('01/07/2020 21:27:28', 'DD/MM/YYYY HH24:MI:SS'), 'cp15');


-- Cash Payments (Subtype of Payment)
REM ********************************************************************
REM Create cash table to hold cash payment records
REM The payment table has a foreign key to this table.

Prompt ******  Creating cash table ....

CREATE TABLE cash (
    payment_id VARCHAR2(11) PRIMARY KEY CHECK (SUBSTR(payment_id, 1, 3) = 'CHs'),
    cash_received DECIMAL(10,2) NOT NULL,
    cash_changed DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_cash_payment FOREIGN KEY (payment_id) REFERENCES payment(payment_id)
);

REM ********************************************************************
REM Input Cash Payment Records

Prompt ******  Inserting Cash Payment Records....

INSERT INTO cash VALUES('CHs1',180.25,0);
INSERT INTO cash VALUES('CHs2',175,1.75);
INSERT INTO cash VALUES('CHs3',300,7.5);
INSERT INTO cash VALUES('CHs4',280.35,0);
INSERT INTO cash VALUES('CHs5',150,5.54999999999998);

-- Card Payments (Subtype of Payment)
REM ********************************************************************
REM Create card table to hold card payment records
REM The payment table has a foreign key to this table.

Prompt ******  Creating card table ....

CREATE TABLE card (
    payment_id VARCHAR2(11) PRIMARY KEY CHECK (SUBSTR(payment_id, 1, 3) = 'CRs'),
    card_num NUMBER(15),
    card_type VARCHAR2(25),
    cardholder_name VARCHAR2(35),
    bank_invoice_no NUMBER(8),
    issuing_bank VARCHAR2(50),
    CONSTRAINT fk_card_payment FOREIGN KEY (payment_id) REFERENCES payment(payment_id)
);

REM ********************************************************************
REM Input Card Payment Records

Prompt ******  Inserting Card Payment Records....

INSERT INTO card VALUES( 'CRs1',186390285743968,'Credit Card', 'Er Ni Ru', 16846396, 'Hong Leong Bank');
INSERT INTO card VALUES( 'CRs2',186390285743968,'Credit Card', 'Er Ni Ru', 18463985, 'Hong Leong Bank');
INSERT INTO card VALUES( 'CRs3',965573968461250,'Credit Card', 'Tajendra A/L Venkatarama', 24038561, 'RHB Bank');
INSERT INTO card VALUES( 'CRs4',338788451107690,'Debit Card', 'Walker Robert Smith', 28463217, 'MayBank');
INSERT INTO card VALUES( 'CRs5',338788451107690,'Debit Card', 'Walker Robert Smith', 36729653, 'MayBank');



-- E-Wallet Payments (Subtype of Payment)
REM ********************************************************************
REM Create ewallet table to hold ewallet payment records
REM The payment table has a foreign key to this table.

Prompt ******  Creating ewallet table ....

CREATE TABLE ewallet (
    payment_id VARCHAR2(11) PRIMARY KEY CHECK (SUBSTR(payment_id, 1, 3) = 'EWs'),
    wallet_provider VARCHAR2(35),
    wallet_transaction_id NUMBER(10),
    wallet_account VARCHAR2(30),
    wallet_ref NUMBER(10),
    wallet_source VARCHAR2(50),
    CONSTRAINT fk_ewallet_payment FOREIGN KEY (payment_id) REFERENCES payment(payment_id)
);

REM ********************************************************************
REM Input Ewallet Payment Records

Prompt ******  Inserting Ewallet Payment Records ....

INSERT INTO ewallet VALUES('EWs1','Walker Robert Smith',6849784765, 'Walker195736', 3715602187, 'Maybank2U Boost');
INSERT INTO ewallet VALUES('EWs2','Charlotte Yii Ken Ai',3000028583, 'CYKAcyka_', 1837460193, 'AmBank GrabPay');
INSERT INTO ewallet VALUES('EWs3','Choong Ming Yee',3693879014, 'Choong Ming Yee', 3629172009, 'Touch n Go');
INSERT INTO ewallet VALUES('EWs4','Bur Shazana Binti Mohamedarifin',6585279439, 'BurShazanaBtMi', 2288355173, 'Bank Islam Touch n Go');
INSERT INTO ewallet VALUES('EWs5','Choong Ming Yee',4134786520, 'Choong Ming Yee', 3629172009, 'Touch n Go');
