/*
INDIVIDUAL ASSIGNMENT SUBMISSION

STUDENT NAME : RICHARD TING LI ZENG
STUDENT ID : 2301973
GROUP NUMBER : G041
PROGRAMME : CS
Submission date and time: 29-apr-25
*/



/* Query 1 (Listing the Popularity of the Items)*/
   select i.item_type,
     ((select food_name from food where item_id = i.item_id and rownum = 1) ||
     (select beverage_name from beverage where item_id = i.item_id and rownum = 1) ||
     (select  dessert_name FROM dessert where item_id = i.item_id AND ROWNUM = 1)) as item_name,
        oi.order_count,oi.total_quantity,
        round(oi.total_quantity * 100 /
              (select sum(oi2.quantity)
               from ordered_item oi2
               where oi2.item_id in (
                  select i2.item_id
                  from item i2
                  where i2.item_type = i.item_type
              )), 2) as selection_percentage
   from item i,
       (select item_id, COUNT(*) order_count, sum(quantity) total_quantity
        from ordered_item
        group by item_id) oi
   where i.item_id = oi.item_id
   and oi.total_quantity > 0
   and (
       select count(*)
       from (
           select i2.item_id
           from item i2, ordered_item oi2
           where i2.item_id = oi2.item_id
           and i2.item_type = i.item_type
           group by i2.item_id
           order by sum(oi2.quantity) desc
       ) ranked_items
       where ranked_items.item_id = i.item_id
   ) = 1
  order by i.item_type, selection_percentage desc;




/* Query 2 */
select
    c.cust_name,
    count(o.order_id) as orders_placed,
    sum(t.total_after) as total_spent,
    round(sum(t.total_after)/count(o.order_id), 2) as avg_spend_per_order,
    to_char(max(o.order_date), 'YYYY-MM-DD') as last_order_date
from customer c, orders o, transaction t
where c.cust_id = o.cust_id
and o.order_id = t.order_id
and t.transaction_status = 'Complete'
group by c.cust_name
order by total_spent desc;


/* Stored procedure 1 */
create or replace procedure flag_refund (
    p_order_id in VARCHAR2,
    p_status out VARCHAR2,
    p_message out VARCHAR2
)
as
    v_transaction_id VARCHAR2(10);
    v_order_exists NUMBER;
    v_payment_count NUMBER;
begin
    p_status := 'FAILURE';
    p_message := 'Refund processing failed';
    
    select count(*) into v_order_exists
    from orders
    where order_id = p_order_id;
    
    if v_order_exists = 0 then
        p_message := 'Order ' || p_order_id || ' does not exist';
        return;
    end if;
    
    begin
        select transaction_id into v_transaction_id
        from transaction
        where order_id = p_order_id
        and transaction_status = 'Complete';
    exception
        when no_data_found then
            p_message := 'No completed transaction found for order ' || p_order_id;
            return;
    end;
    
    select count(*) into v_payment_count
    from payment
    where transaction_id = v_transaction_id
    and payment_status = 'Successful';
    
    if v_payment_count = 0 then
        p_message := 'No successful payments found to refund for order ' || p_order_id;
        return;
    end if;
    
    update payment
    set payment_status = 'Fail'
    where transaction_id = v_transaction_id
    and payment_status = 'Successful';
    
    update orders
    set order_status = 'Terminate'
    where order_id = p_order_id;
    
    p_status := 'SUCCESS';
    p_message := 'Order ' || p_order_id || ' has been marked for refund';
    commit;
    
exception
    when others then
        rollback;
        p_message := 'Refund failed: ' || SQLERRM;
        p_status := 'ERROR';
end;
/

/* Stored procedure 2 */
CREATE OR REPLACE PROCEDURE remove_order_item(
    p_order_id       IN VARCHAR2,
    p_item_id        IN VARCHAR2,
    p_result_message OUT VARCHAR2
)
as
    v_rows_affected NUMBER;
begin
    delete FROM ordered_item
    where order_id = p_order_id AND item_id = p_item_id;

    v_rows_affected := sql%rowcount;
    
    if v_rows_affected = 0 then
        p_result_message := 'Error: Item not found in order';
    else
        p_result_message := 'Item removed from order successfully';
        commit;
    end if;
exception
    when others then
        rollback;
        p_result_message := 'Error removing item: ' || substr(sqlerrm, 1, 200);
end;
/

/* Function 1 */
CREATE OR REPLACE FUNCTION CalculateOrderTotalFunc(
    p_order_id IN VARCHAR2,
    p_show_output IN BOOLEAN DEFAULT TRUE
) return DECIMAL
is
    v_total DECIMAL(10,2) := 0;
    v_order_exists NUMBER;
    v_items_exist NUMBER;
begin
    select count(*) into v_order_exists
    from orders
    where order_id = p_order_id;
    
    if v_order_exists = 0 then
        if p_show_output then
            dbms_output.put_line('Error: Order ' || p_order_id || ' does not exist');
        end if;
        return null; 
    end if;
    
    select count(*) into v_items_exist
    from ordered_item
    where order_id = p_order_id;
    
    if v_items_exist = 0 then
        if p_show_output then
            dbms_output.put_line('Order ' || p_order_id || ' exists but has no items');
        end if;
        return 0; 
    end if;
    
    select sum(oi.quantity * 
        case 
            when i.item_type = 'Food' THEN f.food_price
            when i.item_type = 'Beverage' THEN b.beverage_price
            when i.item_type = 'Dessert' THEN d.dessert_price
        end)
    into v_total
    from ordered_item oi, item i, food f, beverage b, dessert d
    where oi.item_id = i.item_id
    and oi.item_id = f.item_id(+)
    and oi.item_id = b.item_id(+)
    and oi.item_id = d.item_id(+)
    and oi.order_id = p_order_id;
    
    v_total := nvl(v_total, 0);
    
    if p_show_output then
        dbms_output.put_line('Total for Order ' || p_order_id || ': RM' || v_total);
    end if;
    
    return v_total;
exception
    when others then
        if p_show_output then
            dbms_output.put_line('Error calculating total for order ' || p_order_id || ': ' || SQLERRM);
        end if;
        return null;
end;
/

/* Function 2 */
CREATE OR REPLACE FUNCTION get_customer_history(
    p_cust_id IN NUMBER
) return SYS_REFCURSOR
is
    v_cursor SYS_REFCURSOR;
begin
    open v_cursor for
        select c.cust_name, o.order_id, o.order_date, o.order_type, t.transaction_id, t.total_after AS amount_paid, p.payment_method, p.payment_status, r.receipt_id, r.receipt_date
        from customer c, orders o, transaction t, payment p, receipt r
        where c.cust_id = o.cust_id
	and o.order_id = t.order_id
	and t.transaction_id = p.transaction_id
	and t.transaction_id = r.transaction_id
        and c.cust_id = p_cust_id
        and o.order_status = 'Success'
        order by o.order_date desc;
    
    return v_cursor;
exception
    when others then
        if v_cursor%isopen then
            close v_cursor;
        end if;
        raise;
end;
/

