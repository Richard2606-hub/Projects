SELECT discount, COUNT(*) AS Discount_Count
FROM Transaction
GROUP BY discount
ORDER BY discount ASC;

SELECT o.order_type, SUM(t.total_after) AS Total_Payment_Amounts
FROM Orders o, Transaction t
WHERE t.order_id = o.order_id
GROUP BY order_type;

CREATE OR REPLACE PROCEDURE add_item(
    p_item_id       IN Item.item_id%TYPE,
    p_item_type     IN Item.item_type%TYPE,
    p_name          IN VARCHAR2,
    p_price         IN DECIMAL, 
    p_description   IN VARCHAR2
) AS
BEGIN
    -- Insert data into Item table first
    INSERT INTO Item(item_id, item_type)
    VALUES (p_item_id, p_item_type);

    -- Based on item_type, insert data into the appropriate table
    IF LOWER(p_item_type) = 'food' THEN
        INSERT INTO Food(item_id, food_name, food_price, food_description)
        VALUES (p_item_id, p_name, p_price, p_description);

    ELSIF LOWER(p_item_type) = 'beverage' THEN
        INSERT INTO Beverage(item_id, beverage_name, beverage_price, beverage_description)
        VALUES (p_item_id, p_name, p_price, p_description);

    ELSIF LOWER(p_item_type) = 'dessert' THEN
        INSERT INTO Dessert(item_id, dessert_name, dessert_price, dessert_description)
        VALUES (p_item_id, p_name, p_price, p_description);

    ELSE
        RAISE_APPLICATION_ERROR(-20003, 'The process to add item failed. Invalid item type.');
    END IF;

    COMMIT;
END;
/

-- Sample Demo
--Food
SET SERVEROUTPUT ON
EXECUTE add_item('F437','Food','Chipotle Chicken with Chunky Pistachio Sauce',80.00,'Juicy chicken thighs marinated in smoky chipotle peppers, garlic, lime, and olive oil, grilled to perfection and topped with a zesty, chunky sauce of roasted pistachios, fresh cilantro, lemon juice, garlic, olive oil, and a touch of chili for heat.');
--Look through output
SELECT item_id, food_name, food_price, food_description
FROM Food;

CREATE OR REPLACE PROCEDURE insert_order_details (
    p_order_id         IN Orders.order_id%TYPE,
    p_order_date       IN DATE,
    p_order_time       IN TIMESTAMP,
    p_table_num        IN Dine_In.table_num%TYPE DEFAULT NULL, 
    p_delivery_address IN Delivery.delivery_address%TYPE DEFAULT NULL, 
    p_contact_number   IN Delivery.delivery_contact%TYPE DEFAULT NULL
)
AS
    v_order_type Orders.order_type%TYPE;
BEGIN
    -- Step 1: Check if the order exists and get order_type
    SELECT order_type INTO v_order_type
    FROM Orders
    WHERE order_id = p_order_id;

    -- Step 2: Based on the order_type, insert into the appropriate table
    IF LOWER(v_order_type) = 'dine-in' THEN
        INSERT INTO Dine_In (order_id, table_num, dine_in_date, dine_in_time)
        VALUES (p_order_id, p_table_num, p_order_date, p_order_time);

    ELSIF LOWER(v_order_type) = 'takeaway' THEN
        INSERT INTO Takeaway (order_id, pickup_date, pickup_time)
        VALUES (p_order_id, p_order_date, p_order_time);

    ELSIF LOWER(v_order_type) = 'delivery' THEN
        INSERT INTO Delivery (order_id, delivery_address, delivery_contact, delivery_date, delivery_time)
        VALUES (p_order_id, p_delivery_address, p_contact_number, p_order_date, p_order_time);

    ELSE
        RAISE_APPLICATION_ERROR(-20003, 'Failed to insert order details: Invalid order type.');
    END IF;

    COMMIT;
END;
/

-- Sample Demo
-- Assuming the order information is already in the table
INSERT INTO Orders (order_id, order_type, order_status, order_date, order_time, cust_id)
VALUES ('TA02072020n1', 'Takeaway', 'New', TO_DATE('02/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('02/07/2020 11:00:00', 'DD/MM/YYYY HH24:MI:SS'), 15834);

--Takeaway
SET SERVEROUTPUT ON
EXECUTE insert_order_details('TA02072020n1', TO_DATE('02/07/2020', 'DD/MM/YYYY'), TO_TIMESTAMP('02/07/2020 8:00:00', 'DD/MM/YYYY HH24:MI:SS'));

--Look through the output
SELECT order_id, pickup_date, pickup_time
FROM Takeaway;

CREATE OR REPLACE FUNCTION get_hourly_success_counts
  RETURN SYS_REFCURSOR
AS
  result_cursor SYS_REFCURSOR;
BEGIN
  OPEN result_cursor FOR
    SELECT 
      TO_CHAR(order_time, 'YYYY-MM-DD HH24:00:00') AS range_start,
      TO_CHAR(order_time, 'YYYY-MM-DD HH24:59:59') AS range_end,
      COUNT(*) AS success_count
    FROM orders
    WHERE order_status = 'Success'
    GROUP BY TO_CHAR(order_time, 'YYYY-MM-DD HH24')
    ORDER BY range_start;
    
  RETURN result_cursor;
END;
/

CREATE OR REPLACE FUNCTION get_amount_range (
    p_amount IN NUMBER
)
RETURN VARCHAR2
AS
    v_range VARCHAR2(50);
BEGIN
    IF p_amount BETWEEN 0 AND 999 THEN
        v_range := 'RM 0 - 999';
    ELSIF p_amount BETWEEN 1000 AND 1999 THEN
        v_range := 'RM 1000 - 1999';
    ELSIF p_amount BETWEEN 2000 AND 2999 THEN
        v_range := 'RM 2000 - 2999';
    ELSIF p_amount BETWEEN 3000 AND 3999 THEN
        v_range := 'RM 3000 - 3999';
    ELSIF p_amount BETWEEN 4000 AND 4999 THEN
        v_range := 'RM 4000 - 4999';
    ELSE
        v_range := 'RM 5000 and above';
    END IF;

    RETURN v_range;
END;
/


