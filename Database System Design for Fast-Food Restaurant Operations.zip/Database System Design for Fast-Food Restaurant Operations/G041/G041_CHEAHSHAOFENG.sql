/*
INDIVIDUAL ASSIGNMENT SUBMISSION

STUDENT NAME : CHEAH SHAO FENG	
STUDENT ID : 2207459
GROUP NUMBER : G041
PROGRAMME : CS
Submission date and time: 29/4/2025

*/


/* Query 1 */

SELECT p.payment_id, p.payment_method, p.payment_status, p.payment_date, t.total_after
FROM payment p
JOIN transaction t ON p.transaction_id = t.transaction_id
WHERE p.payment_status = 'Pending';


/* Query 2 */

SELECT order_date, COUNT(order_id) AS total_orders
FROM orders
GROUP BY order_date
ORDER BY order_date;


/* Stored procedure 1 */

CREATE OR REPLACE PROCEDURE add_transaction (
    p_transaction_id VARCHAR2,
    p_order_id VARCHAR2,
    p_total_before NUMBER,
    p_discount NUMBER,
    p_tax NUMBER,
    p_total_after NUMBER,
    p_transaction_status VARCHAR2,
    p_transaction_date DATE,
    p_transaction_time TIMESTAMP
) AS
BEGIN
    IF NOT REGEXP_LIKE(p_transaction_id, '^(pr|pd|cp|tm)\d{1,8}$') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Invalid transaction_id format. Must start with pr, pd, cp, or tm followed by 1 to 8 digits.');
    END IF;
    INSERT INTO transaction (
        transaction_id, 
        order_id, 
        total_before, 
        discount, 
        tax, 
        total_after, 
        transaction_status, 
        transaction_date,
        transaction_time
    )
    VALUES (
        p_transaction_id, 
        p_order_id, 
        p_total_before, 
        p_discount, 
        p_tax, 
        p_total_after, 
        p_transaction_status, 
        p_transaction_date,
        p_transaction_time
    );
    DBMS_OUTPUT.PUT_LINE('Transaction created successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred while creating transaction: ' || SQLERRM);
END;
/


/* Stored procedure 2 */

CREATE OR REPLACE PROCEDURE update_transaction_status (
    p_transaction_id VARCHAR2,
    p_new_status VARCHAR2
) AS
BEGIN
    UPDATE transaction
    SET transaction_status = p_new_status
    WHERE transaction_id = p_transaction_id;
    DBMS_OUTPUT.PUT_LINE('Transaction status updated successfully for transaction_id: ' || p_transaction_id);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No transaction found with transaction_id: ' || p_transaction_id);
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
END;
/



/* Function 1 */

CREATE OR REPLACE FUNCTION calculate_total_sales (
    p_cust_id NUMBER
) RETURN NUMBER AS
    v_total_sales NUMBER := 0; 
BEGIN
    SELECT COALESCE(SUM(t.total_after), 0)
    INTO v_total_sales
    FROM transaction t
    JOIN orders o ON t.order_id = o.order_id
    WHERE o.cust_id = p_cust_id;

    RETURN v_total_sales; 
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0; 
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
        RETURN NULL; 
END;
/



/* Function 2 */

CREATE OR REPLACE FUNCTION calculate_avg_completed_transactions RETURN NUMBER AS
    v_avg_value NUMBER; 
BEGIN
    SELECT COALESCE(AVG(total_after), 0)
    INTO v_avg_value
    FROM transaction
    WHERE transaction_status = 'Complete';
    RETURN v_avg_value;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
        RETURN NULL;
END;
/





