/*
INDIVIDUAL ASSIGNMENT SUBMISSION

STUDENT NAME : CHEAH CHUN WAY
STUDENT ID : 22ACB07036
GROUP NUMBER : G041
PROGRAMME : CS
Submission date and time: 29-04-2025
*/



/* Query 1 */
SELECT c.cust_id, c.cust_name, o.order_id, o.order_type
FROM customer c JOIN orders o
ON c.cust_id = o.cust_id
ORDER BY cust_name;


/* Query 2 */
SELECT order_type, count(order_type) AS "Number of Orders by Order Types"
FROM orders
GROUP BY order_type
ORDER BY order_type ASC;


/* Stored procedure 1 */
CREATE OR REPLACE PROCEDURE add_customer (
    p_cust_id IN NUMBER,
    p_cust_name IN VARCHAR2,
    p_cust_address IN VARCHAR2,
    p_cust_contactnumber IN VARCHAR2,
    p_cust_emailaddress IN VARCHAR2
) AS
BEGIN
    INSERT INTO customer (cust_id, cust_name, cust_address, cust_contactnumber, cust_emailaddress)
    VALUES (p_cust_id, p_cust_name, p_cust_address, p_cust_contactnumber, p_cust_emailaddress);
    
    -- Confirmation message
    DBMS_OUTPUT.PUT_LINE('Customer added successfully: ' || p_cust_name);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error adding customer: ' || SQLERRM);
END;
/


/* Stored procedure 2 */
CREATE OR REPLACE PROCEDURE add_order (
    p_order_id IN VARCHAR2,
    p_order_type IN VARCHAR2,
    p_order_status IN VARCHAR2,
    p_order_date IN DATE,
    p_order_time IN TIMESTAMP,
    p_cust_id IN NUMBER
) AS
    v_cust_count NUMBER; -- Variable to check if the customer exists
BEGIN
    -- Validate if the customer exists
    SELECT COUNT(*)
    INTO v_cust_count
    FROM customer
    WHERE cust_id = p_cust_id;

    IF v_cust_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_cust_id || ' does not exist.');
        RETURN;
    END IF;

    -- Insert the order into the orders table
    INSERT INTO orders (
        order_id, order_type, order_status, order_date, order_time, cust_id
    )
    VALUES (
        p_order_id, p_order_type, p_order_status, p_order_date, p_order_time, p_cust_id
    );

    -- Confirmation message
    DBMS_OUTPUT.PUT_LINE('Order ''' || p_order_id || ''' added successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error adding order: ' || SQLERRM);
END;
/


/* Function 1 */
CREATE OR REPLACE FUNCTION calculate_total_revenue
RETURN DECIMAL IS
    v_total_revenue DECIMAL(15,2); -- Variable to store the total revenue
BEGIN
    -- Calculate the total revenue from the 'transaction' table
    SELECT COALESCE(SUM(total_after), 0)
    INTO v_total_revenue
    FROM transaction;

    -- Return the total revenue
    RETURN v_total_revenue;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error calculating total revenue: ' || SQLERRM);
        RETURN 0; -- Return 0 if an error occurs
END;
/

/* Function 2 */
CREATE OR REPLACE FUNCTION calculate_total_sold (
    p_item_id IN VARCHAR2
) RETURN NUMBER IS
    v_total_sold NUMBER; -- Variable to store the total quantity sold
BEGIN
    -- Calculate the total sold for the given item ID
    SELECT SUM(quantity)
    INTO v_total_sold
    FROM ordered_item
    WHERE item_id = p_item_id;

    -- Check if the result is NULL (no records found)
    IF v_total_sold IS NULL THEN
        -- Raise an exception if no records are found
        RAISE_APPLICATION_ERROR(-20001, 'No sales data found for item ID: ' || p_item_id);
    END IF;

    -- Return the total quantity sold
    RETURN v_total_sold;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No sales data found for the specified item ID: ' || p_item_id);
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error calculating total sold: ' || SQLERRM);
        RETURN NULL; -- Return NULL in case of an unexpected error
END;
/