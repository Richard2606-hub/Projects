Group Member 1:

Name: Richard Ting Li Zeng (Leader)
Student ID: 2301973
Course: CS
Practical Session: Friday, 10:30 AM - 12:30 PM
Practical Group: P5
Tutor: Ms.Lai Siew Cheng


Group Member 2:

Name: Leong Kah Han
Student ID: 2203563
Course: IA
Practical Session: Monday, 12:00 PM - 2:00 PM
Practical Group: P8
Tutor: Mr.Goh Chuan Meng


