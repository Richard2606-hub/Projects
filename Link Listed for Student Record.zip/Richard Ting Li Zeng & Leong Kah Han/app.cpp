#include <iostream>
#include 	<fstream>
#include	<string>
#include	<cstdlib>
#include	"List.h"
#include	"Student.h"

using namespace std;


bool CreateStuList(const char *, List *);
bool DeleteStudent(List *, char *);
bool PrintList(List&, int); 
bool InsertExamResult(const char *, List *);
bool PrintStatistic(List);
bool FilterStudent(List, List *, char *, int, int) ;
bool UpdateIDandPhone(List *);
bool FindPotentialFirstClass(List, List *, char *);
int menu();

int main() {

    List studentList, filteredList;
    List* potentialFirstClassList{};
    int choice, source;
    do
    {
            choice = menu();
            switch (choice) {
            case 1:
                CreateStuList("student.txt", &studentList);
                break;
            case 2:
                char id[12];
                cout << "Enter student ID to delete: ";
                cin >> id;
                DeleteStudent(&studentList, id);
                break;
            case 3:
                cout << "Please enter the method that you want to use (1/2)" << endl;// 1 for showing on the screen, 2 for showing on a file
                cin >> source;
                PrintList(studentList, source); // Print to screen
                break;
            case 4:
                InsertExamResult("exam.txt", &studentList);
                break;
            case 5:
                PrintStatistic(studentList);
                break;
            case 6:
                char course[3];
                int year, totalcredit;
                cout << "Enter course: ";
                cin >> course;
                cout << "Enter year: ";
                cin >> year;
                cout << "Enter total credits earned: ";
                cin >> totalcredit;
                FilterStudent(studentList, &filteredList, course, year, totalcredit);
                break;
            case 7:
                UpdateIDandPhone(&studentList);
                if (true)
                {
                    cout << "Updated student list:" << endl;
                    PrintList(studentList, 1); // Print to screen (assuming PrintList function exists)
                }
                else if (false)
                {
                    cout << "Cannot print the list" << endl;
                }
                break;
            case 8:
                char course2[3]; // Changed variable name from 'course' to 'course2'
                cout << "Enter course: ";
                cin >> course2;
                FindPotentialFirstClass(studentList, potentialFirstClassList, course2);
                break;
            case 9:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
            }
    }while (choice != 9);
    return 0;
}

 //Function to create a student list from a file
bool CreateStuList(const char* filename, List* list) {
    
    Student student,temp;
    ifstream inFile;
    inFile.open(filename);
    char redundant[256];
    Node* cur;
    cur = list->head; 
    
    if (inFile.fail()) {
            cout << "Error: Unable to open file " << filename << endl;
            return false;
    }
    else 
    {
        while (inFile >> redundant)
        {
            inFile >> redundant >> redundant;
            inFile >> student.id;
            inFile >> redundant >> redundant;
            inFile.getline(student.name, 20);
            inFile.ignore();
            inFile >> redundant >> redundant;
            inFile >> student.course;
            inFile >> redundant >> redundant;
            inFile >> student.phone_no;

            for (int i = 1; i <= list->size(); i++) {
                if (list->get(i, temp)) {
                    if (student.compareID(temp))
                    {
                        cout << "Warning: Duplicate record found for student ID " << student.id << ". Skipping..." << endl;
                        return true;
                    }

                }
                    if (!(student.compareID(temp)))
                    {
                        list->insert(student);
                        return false;
                    }
                    else
                        cout << " The record of the student" << student.name << "(ID:" << student.id << " have benn stored successfully" << endl;

                    return true;
                
                if (!(list->get(i, temp)))
                {
                    cout << "Empty file cannot be read.";
                    return false;
                }

            }
        }
    }
}



// Function to delete a student from the list by ID
bool DeleteStudent(List* list, char* id) {
    if (list->empty()) {
        cout << "Error: Student list is empty." << endl;
        return false;
    }

    Student student;
    bool found = false;
    for (int i = 1; i <= list->size(); ++i) {
        if (list->get(i, student)) {
            if (strcmp(student.id, id) == 0) {
                found = true;
                break;
            }
        }
    }

    if (found && list->remove(*id)) {
        cout << "Student with ID " << id << " has been deleted successfully." << endl;
        return true;
    }
    else {
        cout << "Error: Student with ID " << id << " not found." << endl;
        return false;
    }
}


// Function to print the student list
bool PrintList(List &list, int source){
    Student student;
    while (source == 1 || source == 2)
    {
        if (source == 1) {
            Node* cur;

            //special case
            if (list.empty())
            {
                cout << "  Cannot print from empty list  " << endl;
                return false;
            }
            else
                return true;

            //normal case
            //assign cur  to the first node 
            cur = list.head;

            //go through each node in the list - traverse the list
            while (cur != NULL)
            {
                //operation - print the item's value 
                cur->item.print(cout);

                //move cur to next node
                cur = cur->next;

                //Output Records
                for (int i = 1; i < (list.size()); i++)
                {
                    cout << "List of Student" << endl;
                    cout << "******************************************************STUDENT " << i << "******************************************************" << endl;
                    cur->item.print(cout);
                    cout << "--------------------------------------------------PAST EXAM RESULT:--------------------------------------------------" << endl;

                    if (!(cur->item.exam_cnt = 0))
                    {
                        for (int j = 0; j < cur->item.exam_cnt; j++)
                        {
                            cur->item.exam[j].print(cout);
                        }
                    }
                    else
                    {
                        if (cur->item.exam_cnt = 0)
                        {
                            cout << student.name << " haven't taken any exam yet" << endl;
                            cur = cur->next;
                        }
                    }
                    cout << "******************************************************STUDENT " << i << "******************************************************" << endl;
                }

            }

            if (source == 2)
            {
                ofstream outFile;
                outFile.open("student_result.txt");
                Node* cur;
                cur = list.head;
                while (cur != NULL)
                {
                    cur->item.print(outFile);
                    cur = cur->next;

                    //Output Records
                    for (int i = 1; i < (list.size()); i++)
                    {
                        outFile << "List of Student" << endl;
                        outFile << "******************************************************STUDENT " << i << "******************************************************" << endl;
                        cur->item.print(outFile);
                        outFile << "--------------------------------------------------PAST EXAM RESULT:--------------------------------------------------" << endl;

                        if (!(cur->item.exam_cnt = 0))
                        {
                            for (int j = 0; j < cur->item.exam_cnt; j++)
                            {
                                cur->item.exam[j].print(outFile);
                            }
                        }
                        else
                        {
                            if (cur->item.exam_cnt = 0)
                            {
                                outFile << student.name << " haven't taken any exam yet" << endl;
                                cur = cur->next;
                            }
                        }
                        outFile << "******************************************************STUDENT " << i << "******************************************************" << endl;
                    }
                }
            }


        }while (!(source == 1 || source == 2));
        return true;
    }
}
// Function to insert exam results into the student list
bool InsertExamResult(const char* filename, List* list) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return false;
    }

    int exam_trimester, exam_year, student_id, num_subjects;
    double exam_gpa;
    char subject_code[10];
    double subject_marks;

    while (file >> exam_trimester >> exam_year >> student_id >> exam_gpa >> num_subjects) {
        // Find the student
        Node* studentNode = list->find(student_id);
        if (!studentNode) {
            cout << "Student with ID " << student_id << " not found." << endl;
            continue;
        }
        Student& student = studentNode->item;

        // Create and fill the exam
        Exam new_exam;
        new_exam.trimester = exam_trimester;
        new_exam.year = exam_year;
        new_exam.gpa = exam_gpa;
        new_exam.numOfSubjects = num_subjects;

        for (int i = 0; i < num_subjects; ++i) {
            file >> subject_code >> subject_marks;
            strcpy(new_exam.sub[i].subject_code, subject_code);
            new_exam.sub[i].marks = subject_marks;
        }

        // Calculate GPA for the exam
        new_exam.calculateGPA();

        // Insert the exam into the student's list of exams
        student.exam[student.exam_cnt++] = new_exam;

        // Calculate current CGPA for the student
        student.calculateCurrentCGPA();
    }

    file.close();
    return true;
}


// Function to print statistics based on the student list
bool PrintStatistic(List list) {
    if (list.empty()) {
        cout << "Empty list\n";
        return false;
    }

    int totalStudents = list.size();
    int csStudents = 0, iaStudents = 0, ibStudents = 0, cnStudents = 0, ctStudents = 0;
    float totalCGPA = 0, totalSubjects = 0, totalCredits = 0;

    Node* cur = list.head;
    while (cur != NULL) {
        Student student = cur->item;
        totalCGPA += student.current_cgpa;

        if (strcmp(student.course, "CS") == 0) csStudents++;
        else if (strcmp(student.course, "IA") == 0) iaStudents++;
        else if (strcmp(student.course, "IB") == 0) ibStudents++;
        else if (strcmp(student.course, "CN") == 0) cnStudents++;
        else if (strcmp(student.course, "CT") == 0) ctStudents++;

        // Calculate average subjects taken per semester
        totalSubjects += student.exam_cnt;

        // Calculate average credits earned per semester
        totalCredits += student.totalCreditsEarned;

        cur = cur->next;
    }

    // Calculate averages
    float averageCGPA = totalCGPA / totalStudents;
    float averageSubjects = totalSubjects / totalStudents;
    float averageCredits = totalCredits / totalStudents;

    // Print statistics
    cout << "Total Students: " << totalStudents << endl;
    cout << "\tCS Students � " << csStudents << endl;
    cout << "\tIA Students � " << iaStudents << endl;
    cout << "\tIB Students � " << ibStudents << endl;
    cout << "\tCN Students � " << cnStudents << endl;
    cout << "\tCT Students � " << ctStudents << endl;
    cout << "\nAverage CGPA: " << averageCGPA << endl;
    cout << "\tAverage Subjects Taken Per Semester: " << averageSubjects << endl;
    cout << "\tAverage Credits Earned Per Semester: " << averageCredits << endl;

    return true;

}


// Function to filter students based on course, year, and total credits earned
bool FilterStudent(List list, List* list2, char* course, int year, int totalCredit) {
    if (list.empty()) {
        cout << "Error: Student list is empty." << endl;
        return false;
    }

    // Filter students based on provided criteria// Match course (or any course if course is empty)
    for (int i = 0; i < list.size(); i++)
    {
        Student student;
        if ((list.get(i, student) && strcmp(student.course, course) == 0 || course[0] == '\0') && list2->insert(student))
        {
            // Check if any filtered students were found
            if (list2->empty()) {
                cout << "No students found matching the filter criteria." << endl;
            }
            else {
                // Print filtered student list
                cout << "Filtered student list:" << endl;
                PrintList(*list2, 1); // Print to screen (assuming PrintList function exists)
            }
           
        }
        else
        {
            
            return false;
        }
    } return true;
}

// Function to update student ID and phone numbers
bool UpdateIDandPhone(List* list) {
    Node* cur;
    cur = list->head;
    Student student;

    while (cur != NULL)
    { 
        char idName[12];
        for (int i = 1; i <= list->size(); i++) {

            if (!isdigit(cur->item.id[0])) {
                cur = cur->next;
                continue;
            }
            while (student.course[3] = 'CS' || 'IA' || 'IB' || 'CN' || 'CT') {
                if (strcmp(cur->item.course, "CS") == 0) {
                    strcpy(idName, "BCS");
                }
                if (strcmp(cur->item.course, "IA") == 0) {
                    strcpy(idName, "BIA");
                }
                if (strcmp(cur->item.course, "IB") == 0) {
                    strcpy(idName, "BIB");
                }
                if (strcmp(cur->item.course, "CN") == 0) {
                    strcpy(idName, "BCN");
                }
                if (strcmp(cur->item.course, "CT") == 0) {
                    strcpy(idName, "BCT");
                }
            }
            strcat(idName, cur->item.id);

            strcpy(cur->item.id, idName);

            char newPhone[10];

            int k = 0;

            for (int j = 0; j < 8; j++) {
                if (cur->item.phone_no[j] != '-') {
                    newPhone[k] = cur->item.phone_no[j];
                    k++;
                }

            }
            newPhone[k] = '\0';



            if (int(cur->item.phone_no[0]) % 2 == 1) {
                strcpy(cur->item.phone_no, "01");
                strcat(cur->item.phone_no, newPhone);
            }
            else {
                strcpy(cur->item.phone_no, "02");
                strcat(cur->item.phone_no, newPhone);
            }

            cur = cur->next;
        }
    }
}

bool FindPotentialFirstClass(List list1, List* list2, char* course) {
   
    Node* cur;
    cur = list1.head;
    double totalcredithour;
    Subject subject;
    Student student;

    if (list1.empty()) {
        cout << "Error: Student list is empty." << endl;
        return false;
    }

   
    // Traverse list and identify potential first-class students
    for (int i = 0; i < list1.size(); i++) {
        if (cur->item.exam_cnt >= 3) {
            for (int j = 0; j < cur->item.exam_cnt; j++)
            {
                if (cur->item.exam[j].gpa >= 3.75000)
                {
                    for (int k = 0; k < cur->item.exam[k].numOfSubjects; k++)
                        totalcredithour = subject.credit_hours + cur->item.exam[j].sub[k].credit_hours;

                    if (totalcredithour >= 12)
                        return true;
                    else
                        return false;

                    cur = cur->next;
                    return true;
                }
                else
                {
                    cur = cur->next;
                    return false;
                }
            }

        }
        if (cur->item.exam_cnt >= 3 && true && true)
        {
            list2->insert(cur->item);
            cur = cur->next;
        }
        else
            cur = cur->next;
    }


    // Check if any potential first-class students were found
    if (list2->empty()) {
        cout << "No potential first-class students found." << endl;
    }
    else {
        // Print potential first-class student list
        cout << "Potential First-Class Students (CGPA >= 3.75 ):" << endl;
        PrintList(*list2, 1); // Print to screen (assuming PrintList function exists)
    }

    return true;
}

// Function to display the menu and get user choice
int menu() {
    int choice;
    cout << "Menu:" << endl;
    cout << "1. Create student list" << endl;
    cout << "2. Delete Student" << endl;
    cout << "3. Print student list" << endl;
    cout << "4. Insert exam result" << endl;
    cout << "5. Print Exam Statistic" << endl;
    cout << "6. Filter Student" << endl;
    cout << "7. Update Student�s ID and Phone" << endl;
    cout << "8. Find Potential First Class Student" << endl;
    cout << "9. Exit" << endl;
    cout << "Enter your choice: ";
    cin >> choice;
    return choice;
}