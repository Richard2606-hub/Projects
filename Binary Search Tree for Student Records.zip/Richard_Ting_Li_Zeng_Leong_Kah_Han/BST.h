#ifndef BT_type
#define BT_type

#include	"BTNode.h"
#include	"Queue.h"


struct BST {

	int		count;
	BTNode* root;

	// print operation for BST (same as BT)					
	void preOrderPrint2(BTNode*);	// recursive function for preOrderPrint()
	void inOrderPrint2(BTNode*);	// recursive function for inOrderPrint()
	void postOrderPrint2(BTNode*);	// recursive function for postOrderPrint()

	// sample operation (extra functions) - same as BT
	void countNode2(BTNode*, int&);		// recursive function for countNode()
	bool fGS2(type, BTNode*);					// recursive function for findGrandsons(): to find the grandfather
	void fGS3(BTNode*, int);				// recursive function for findGrandsons(): to find the grandsons after the grandfather has been found

	// basic functions for BST
	void insert2(BTNode*, BTNode*);		// recursive function for insert() of BST
	void case3(BTNode*);					// recursive function for remove()
	void case2(BTNode*, BTNode*);		// recursive function for remove()
	bool remove2(BTNode*, BTNode*, type);	// recursive function for remove()

	// basic functions for BST
	BST();
	bool empty();
	int size();
	bool insert(type);		// insert an item into a BST
	bool remove(type);			// remove an item from a BST

	// print operation for BST (same as BT)
	void preOrderPrint();			// print BST node in pre-order manner
	void inOrderPrint();			// print BST node in in-order manner
	void postOrderPrint();			// print BST node in post-order manner
	void topDownLevelTraversal();	// print BST level-by-level

	// sample operation (extra functions) - same as BT
	int countNode();		// count number of tree nodes
	bool findGrandsons(type);	// find the grandsons of an input father item

	//function created
	bool CloneSubtree(BST, type);       //Function to clone the sub tree
	void CloneSubtree2(BST, type, BTNode*, int);      //recursion function for CloudSubTree function
	bool printLevelNodes(); // print the level of every nodes
	void printLevelNodes2(BTNode*, int);   // recursion function for printLevelNodes function
	bool printPath();     // print the path of the tree traced by every nodes
	void printPath2(BTNode*, Queue&);    //recursion function for printPath function
	bool LeafofTree(BTNode* cur);    //the nodes of tree and subtrees, function for checking the nodes is the leaf
	bool display(int, int);    //Function to display the student info by using screen or file
	bool deepestNodes();       //Function to show the deepest node(s) of the tree
	void antiInOrderPrint();        // print BST node in anti in-order manner
	void antiInOrderPrint2(BTNode*);// recursive function for antiInOrderPrint function
	void enqueueNextLevelNode(); //Function to enqueue all of the next level node
};




#endif