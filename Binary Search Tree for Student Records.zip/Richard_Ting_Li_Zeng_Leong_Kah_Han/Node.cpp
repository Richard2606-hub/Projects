#include <iostream>
#include "Node.h"



Node::Node(type2 newItem) {
	item = newItem;
	next = NULL;
}
