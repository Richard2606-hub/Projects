#include <iostream>
#include <fstream>
#include <algorithm>
#include "BST.h"


using namespace std;

Queue queue;
BTNode* cur;

BST::BST() {
	root = NULL;
	count = 0;
}


bool BST::empty() {
	if (count == 0) return true;
	return false;
}


int BST::size() {
	return count;
}


void BST::preOrderPrint() {
	if (root == NULL) return;// handle special case
	else preOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::preOrderPrint2(BTNode *cur) {

	if (cur == NULL) return;
	cur->item.print(cout);
	preOrderPrint2(cur->left);
	preOrderPrint2(cur->right);
}


void BST::inOrderPrint() {
	if (root == NULL) return;// handle special case
	else inOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::inOrderPrint2(BTNode *cur) {

	if (cur == NULL) return;

	inOrderPrint2(cur->left);
	cur->item.print(cout);
	inOrderPrint2(cur->right);
}


void BST::postOrderPrint() {
	if (root == NULL) return;// handle special case
	else postOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::postOrderPrint2(BTNode *cur) {
	if (cur == NULL) return;
	postOrderPrint2(cur->left);
	postOrderPrint2(cur->right);
	cur->item.print(cout);
}



int BST::countNode() {
	int	counter = 0;
	if (root == NULL) return 0;
	countNode2(root, counter);
	return counter;
}


void BST::countNode2(BTNode *cur, int &count) {
	if (cur == NULL) return;
	countNode2(cur->left, count);
	countNode2(cur->right, count);
	count++;
}


bool BST::findGrandsons(type grandFather) {
	if (root == NULL) return false;
	return (fGS2(grandFather, root));
}


bool BST::fGS2(type grandFather, BTNode *cur) {
	if (cur == NULL) return false;
	//if (cur->item == grandFather) {
	if (cur->item.compare2(grandFather)){

		fGS3(cur, 0);// do another TT to find grandsons
		return true;
	}
	if (fGS2(grandFather, cur->left)) return true;
	return fGS2(grandFather, cur->right);
}


void BST::fGS3(BTNode *cur, int level) {
	if (cur == NULL) return;
	if (level == 2) {
		cur->item.print(cout);
		return;  // No need to search downward
	}
	fGS3(cur->left, level + 1);
	fGS3(cur->right, level + 1);
}



void BST::topDownLevelTraversal() {
	BTNode			*cur;
	Queue		    q;


	if (empty()) return; 	// special case
	q.enqueue(root);	// Step 1: enqueue the first node
	while (!q.empty()) { 	// Step 2: do 2 operations inside
		q.dequeue(cur);
		if (cur != NULL) {
			cur->item.print(cout);

			if (cur->left != NULL)
				q.enqueue(cur->left);

			if (cur->right != NULL)
				q.enqueue(cur->right);
		}
	}
}

//insert for BST
bool BST::insert(type newItem) {
	BTNode	*cur = new BTNode(newItem);
	if (!cur) return false;		// special case 1
	if (root == NULL) {
		root = cur;
		count++;
		return true; 			// special case 2
	}
	insert2(root, cur);			// normal
	count++;
	return true;
}


void BST::insert2(BTNode *cur, BTNode *newNode) {
	//if (cur->item > newNode->item) {
	if (cur->item.compare1(newNode->item)){
		if (cur->left == NULL)
			cur->left = newNode;
		else
			insert2(cur->left, newNode);
	}
	else {
		if (cur->right == NULL)
			cur->right = newNode;
		else
			insert2(cur->right, newNode);
	}
}

bool BST::remove(type item) {
	if (root == NULL) return false; 		// special case 1: tree is empty
	return remove2(root, root, item); 		// normal case
}

bool BST::remove2(BTNode *pre, BTNode *cur, type item) {

	// Turn back when the search reaches the end of an external path
	if (cur == NULL) return false;

	// normal case: manage to find the item to be removed
	//if (cur->item == item) {
	if (cur->item.compare2(item)){
		if (cur->left == NULL || cur->right == NULL)
			case2(pre, cur);	// case 2 and case 1: cur has less than 2 sons
		else
			case3(cur);		// case 3, cur has 2 sons
		count--;				// update the counter
		return true;
	}

	// Current node does NOT store the current item -> ask left sub-tree to check
	//if (cur->item > item)
	if (cur->item.compare1(item))
		return remove2(cur, cur->left, item);

	// Item is not in the left subtree, try the right sub-tree instead
	return remove2(cur, cur->right, item);
}

void BST::case2(BTNode *pre, BTNode *cur) {

	// special case: delete root node
	if (pre == cur) {
		if (cur->left != NULL)	// has left son?
			root = cur->left;
		else
			root = cur->right;

		free(cur);
		return;
	}

	if (pre->right == cur) {		// father is right son of grandfather? 
		if (cur->left == NULL)			// father has no left son?
			pre->right = cur->right;			// connect gfather/gson
		else
			pre->right = cur->left;
	}
	else {						// father is left son of grandfather?
		if (cur->left == NULL)			// father has no left son? 
			pre->left = cur->right;				// connect gfather/gson
		else
			pre->left = cur->left;
	}

	free(cur);					// remove item
}


void BST::case3(BTNode *cur) {
	BTNode		*is, *isFather;

	// get the IS and IS_parent of current node
	is = isFather = cur->right;
	while (is->left != NULL) {
		isFather = is;
		is = is->left;
	}

	// copy IS node into current node
	cur->item = is->item;

	// Point IS_Father (grandfather) to IS_Child (grandson)
	if (is == isFather)
		cur->right = is->right;		// case 1: There is no IS_Father    
	else
		isFather->left = is->right;	// case 2: There is IS_Father

	// remove IS Node
	free(is);
}

bool BST::deepestNodes() {
	Queue queue2;
	int nodecounting, deepest=0, level=0;
	BTNode * temp;
	if (root == NULL) 
		return false;
	
	queue.enqueue(root);

	while (!queue.empty()) {
		// nodecounting indicates number of nodes at current level.
		nodecounting = queue.size();
		level++;
		
		if (level > deepest) {
			while (!queue2.empty())
				queue2.dequeue(temp);
			deepest = level;
		}
		
		else
			level = level;
		
		while (nodecounting > 0) {
			queue.dequeue(cur);// Dequeue all nodes of current level

			if (LeafofTree(cur))
				queue2.enqueue(cur);
			enqueueNextLevelNode();

			nodecounting--;
		}
	}
	cout << "Deepest level of the deepest node: " << level << endl;
	cout << "Deepest Nodes : ";
	while (!queue2.empty()) {
		queue2.dequeue(temp);
		cout << temp->item.id << endl;
	}
	return true;
}

bool BST::display(int order, int source) {
	Queue queue1;
	BTNode* temp;
	BST t1;
	switch (order){
	case 1:
		inOrderPrint();
		if (source == 1) {
			int k = 0;
			while (!queue1.empty()) {
				queue1.dequeue(temp);
				temp->item.print(cout);
			}
			cout << t1.size() << " number of records have successfully shown on the screen." << endl;
		}
		else if (source == 2) {
			ofstream outFile("student-info.txt");
			if (outFile) {
				while (!queue1.empty()) {
					queue1.dequeue(temp);
					temp->item.print(outFile);
				}
				cout << "Successfully read to student - info.txt." << endl;
				cout << t1.size() << " number of records have successfully recorded into the text file." << endl;
			}
			else {
				cout << "Failed to open file.";
				return false;
			}
			outFile.close();
		}
		break;
	case 2:
		antiInOrderPrint();
		if (source == 1) {
			int k = 0;
			while (!queue1.empty()) {
				queue1.dequeue(temp);
				temp->item.print(cout);
			}
			cout << t1.size() << " number of records have successfully shown on the screen." << endl;
		}
		else if (source == 2) {
			ofstream outFile("student-info.txt");
			if (outFile) {
				while (!queue1.empty()) {
					queue1.dequeue(temp);
					temp->item.print(outFile);
				}
				cout << "Successfully read to student - info.txt." << endl;
				cout << t1.size() << " number of records have successfully recorded into the text file." << endl;
			}
			else {
				cout << "Failed to open file.";
				return false;
			}
			outFile.close();
		}
		break;
	}
	return true;
}

bool BST::CloneSubtree(BST t1, type item) {
	BST t2;

	if (t1.root == NULL) {
		cout << "Tree is empty! Please ensure that you have read file!" << endl;
		return false;
	}

	t2.root = NULL;
	CloneSubtree2(t2, item, t1.root, 0);

	/*if (t2.root = NULL) {
		return false;
		cout << "Invalid input or invalid ID, please try again" << endl;  //the code for blocking the invalid input, have success to block the NULL but block the not NULL at the same time.
	}*/
	return true;
}

void BST::CloneSubtree2(BST t2, type item, BTNode* cur, int count) { 
	if (cur == NULL)
		return;
	
	if (cur->item.compare2(item)) {
		count = 1;
		insert(cur->item);
	}
	
	
	CloneSubtree2(t2, item, cur->left, count);
	CloneSubtree2(t2, item, cur->right, count);
}

bool BST::printLevelNodes() {
	Queue queue;
	int level = 0;
	BTNode* cur;
	
	if (root == NULL) 
		return false;
	
	queue.enqueue(root);

	while (!queue.empty()) {
		// nodecounting indicates number of nodes at current level.
		int nodecounting;
		nodecounting = queue.size();
		level++;
		cout << "Level " << level << ": ";

		while (nodecounting > 0) {
			queue.dequeue(cur);// Dequeue all nodes of current level
			cout << cur->item.id << endl;

			enqueueNextLevelNode();
			nodecounting--;
		}
	}
	return true;
}

bool BST::printPath() {
	Queue queue2;

	if (root == NULL)
		return false;
	
	printPath2(root, queue2);

	return true;
}

void BST::printPath2(BTNode* cur, Queue& q2) {
	Queue queue;
	BTNode* temp;
	
	if (cur == NULL)
		return;

	q2.enqueue(cur);
	int j = q2.size();

	if (LeafofTree(cur)) {
		for (int i = 0; i < j; i++){
			q2.dequeue(temp);
			cout << temp->item.id << "\t";
			if (!cur->item.compare2(temp->item)) {
				q2.enqueue(temp);
			}
		}
		cout << endl;
	}

	printPath2(cur->left, q2);
	printPath2(cur->right, q2);

	for (int i = 0; i < j; i++) {
		q2.dequeue(temp);
		if (i < j - 1)
			queue.enqueue(temp);
	}
	while (!queue.empty()) {
		queue.dequeue(temp);
		q2.enqueue(temp);
	}
}

bool BST::LeafofTree(BTNode* cur) {
	if (cur != NULL) {
		if (cur->left == nullptr && cur->right == nullptr)
			return true;
	}
	return false;
}

void BST::enqueueNextLevelNode(){

	if (cur->left != NULL)
	queue.enqueue(cur->left);
	if (cur->right != NULL)
	queue.enqueue(cur->right);
}

void BST::antiInOrderPrint() {
	if (root == NULL) 
		return;                  // handle special case
	else 
		antiInOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::antiInOrderPrint2(BTNode* cur) {

	if (cur == NULL) 
		return;

	antiInOrderPrint2(cur->right);
	cur->item.print(cout);
	antiInOrderPrint2(cur->left);
}