Group Member 1:

Name: Richard Ting Li Zeng (Leader)
Student ID: 2301973
Course: CS
Practical Session: Friday, 10:30 AM - 12:30 PM
Practical Group: P5
Tutor: Ms.Lai Siew Cheng


Group Member 2:

Name: Leong Kah Han
Student ID: 2203563
Course: IA
Practical Session: Monday, 12:00 PM - 2:00 PM
Practical Group: P8
Tutor: Mr.Goh Chuan Meng



Errors & Bugs
1) There is a bug in readFile function. the function is able to read the files by typing the file name with .txt but there will be read repeatly if a text file has been input more than one time.
Group Member 1:

Name: Richard Ting Li Zeng (Leader)
Student ID: 2301973
Course: CS
Practical Session: Friday, 10:30 AM - 12:30 PM
Practical Group: P5
Tutor: Ms.Lai Siew Cheng

Group Member 2:

Name: Leong Kah Han
Student ID: 2203563
Course: IA
Practical Session: Monday, 12:00 PM - 2:00 PM
Practical Group: P8
Tutor: Mr.Goh Chuan Meng

Errors & Bugs
1) There is a bug in readFile function. the function is able to read the files by typing the file name with .txt but there will be read repeatly if a text file has been input more than one time.

2) For CloneSubtree function, there is a bug on blocking the invalid ID on cloning the subtrees. The code is able to show the tree and the function cannot show that there is an invalid input when users input the invalid ID for the data stored. And, if there is and invalid id, the system will also show the t1, which is the orginal tree, and show out the t2 list without any info. 

3) There is another bug that is worth noting that we have added code for blocking the NULL condition or invalid ID, but we can block the NULL and also block the not NULL at the same time.

4) The info that we have read into the system cannot be deleted in time since that there is no any functions to delete the info and have to exit the program so that the system is able to delete the info.

5) Another bug is that users will be confused when there is no any differences whether they input the file into uppercase or lowercase. 

* For this assignment, we have provided some additional text file for program testing. Markers are able to have a test on having several text file read at the same time with the function provided.
