#include	<iostream>
#include	<fstream>
#include	<cstdlib>
#include	<cstdio>
#include	<ctime>
#include	"BST.h"
#include    "Student.h"

using namespace std;

bool readFile(const char*, BST*); //function for read txt file for the data storing to the tree
int menu(); //function for showing menu

BST t1, t2;
type stu;
type2 node;
int choice, order, source;
char filename[20];

int main() {

	while (true) {

		int choice = menu();

		switch (choice)
		{

		case 1:
			cout << "Read Data To Binary Search Tree" << endl;
			cout << "Please key in the filename that would you like to store (with .txt)" << endl;
			cin >> filename;
			readFile(filename, &t1);
			cout << endl;
			break;

		case 2:
			if (!t1.empty())
			{
				cout << "Print Deepest Nodes In Tree" << endl;
				cout << endl;
				t1.deepestNodes();
				break;
			}
			else {
				cout << "Tree is empty, please read some records." << endl;
			}

		case 3:
			if (!t1.empty())
			{
				cout << "Display Output From Tree" << endl;
				cout << "Enter the type of order you want to print in,(1 = ascending, 2 = descending) : ";
				cin >> order;
				cout << "Choose the source of output you want to print at,(1 = print screen, 2 = print to a file) : ";
				cin >> source;
				t1.display(order, source);
				break;
			}
			else {
				cout << "Tree is empty, please read some records." << endl;
			}
		case 4:
			if (!t1.empty()) {
				cout << "Subtree Cloning" << endl;
				int cloneid;
				cout << "Enter the ID you want to clone: ";
				cin >> cloneid;
				type cloneitem;
				cloneitem.id = cloneid;

				bool Successcloned = t2.CloneSubtree(t1, cloneitem);

				if (Successcloned) {
					cout << "Subtree cloned successfully." << endl;
					cout << "Original Tree (t1) :" << endl;
					t1.preOrderPrint();
					cout << "Cloned Subtree(t2) :" << endl;
					t2.preOrderPrint();
				}
				else {
					cout << "Cannot clone subtree or ID not found" << endl;
				}
			}
			else {
				cout << "Tree is empty, please read some records." << endl;
			}
			break;


		case 5:
			if (!t1.empty()){
				cout << "Print Level Nodes" << endl;
				t1.printLevelNodes();
			}
			else 
				cout << "Tree is empty, please read some records" << endl;
			break;
		case 6:
			if (!t1.empty()){
				cout << "Print Path" << endl;
				t1.printPath();
			}
			else 
				cout << "Tree is empty, please read some records." << endl;
			break;

		case 7:
			cout << "Thank you. Have a Nice Day." << endl;
			break;

		default:
			cout << "Invalid input. Please try again." << endl;
			break;

		}
		if (choice == 7)
			break;
	}
	
}

bool readFile(const char* filename, BST* t1) {
	char student[50];

	ifstream file(filename);
	if (!file.is_open()) {
		cout << " Cannot Read the file" << endl;
		return false; // Return false if file not successfully open
	}

	else
	{
		while (!file.eof())
		{
			for (int i = 0; i < 3; i++)
				file >> student;
			file >> stu.id;

			for (int i = 0; i < 2; i++)
				file >> student;
			file.getline(stu.name, 30);

			for (int i = 0; i < 2; i++)
				file >> student;
			file.getline(stu.address, 70);

			for (int i = 0; i < 2; i++)
				file >> student;
			file >> stu.DOB;

			for (int i = 0; i < 3; i++)
				file >> student;
			file >> stu.phone_no;

			for (int i = 0; i < 2; i++)
				file >> student;
			file >> stu.course;

			for (int i = 0; i < 2; i++)
				file >> student;
			file >> stu.cgpa;

			if (!t1->insert(stu)) 
				return false;
		}
		file.close();
		cout << t1->size() << " number of records have successfully read." << endl;
	}
	return true;
}

int menu() {
	int choice;
	cout << "Menu:" << endl;
	cout << "1. Read Data to BST" << endl;
	cout << "2. Print Deepest Nodes" << endl;
	cout << "3. Display Student" << endl;
	cout << "4. Clone Subtree" << endl;
	cout << "5. Print Level Nodes" << endl;
	cout << "6. Print Path" << endl;
	cout << "7. Exit" << endl;
	cout << "Enter your choice: ";
	cin >> choice;
	return choice;
}
