#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;

const int maximumnumberofwards = 10000; // Maximum number of hospital wards
const int maximumpatientsperward = 4; // Maximum number of patients per ward
const int maximumnumberofmedicine = 100; // Maximum number of medicines
int occupied = 0;

struct Patient {
    string name;
    int age;
};

struct patient {
    int patientID;
    string name;
    int age;
    string diagnosis;
};

struct Ward {
    Patient patients[maximumpatientsperward];
    int patientCount;
};

Ward wards[maximumnumberofwards]; // Array of hospital wards

struct Medicine {
    string name;
    int quantity;
    double price;
};

Medicine medications[maximumnumberofmedicine]; // Array to store medicines
int medicinecount = 0; // Current number of medicines

struct Doctor {
    string name;
    string specialization;
    string phoneNumber;
    string IDNum;
    string age;
    bool available;

    Doctor() :available(true) {}
};

Doctor doctors[100];
int totalDoctors = 0;

void medicalconsultation()
{

    string name;
    int age;
    string symptom;
    string diagnosis;
    int i;


    cout << "Welcome to the Medical Consultation System!" << endl;
    cout << "Please enter your name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Please enter your age: ";
    cin >> age;
    cin.ignore();
    cout << "--------------------------------------" << endl;
    cout << "|The common symptoms:                 |" << endl;
    cout << "|* fever                              |" << endl;
    cout << "|* cough                              |" << endl;
    cout << "|* others                             |" << endl;
    cout << "|Press '4' to exit this consultation. |" << endl;
    cout << "---------------------------------------" << endl;
    cout << "Please describe your symptoms: ";
    cin >> symptom;
    cout << endl;
    if (symptom == "fever")
    {
        cout << "Some common health problems or conditions that can cause fever include:" << endl;
        cout << "Infections: Fever is often a sign of infection, such as a bacterial or viral infection" << endl;
        cout << "Autoimmune Diseases : Some autoimmune diseases, like lupus, can cause fever as the body's immune system mistakenly attacks healthy tissues." << endl;
        cout << "Heat - Related Illnesses : Exposure to extreme heat or heatstroke can lead to a fever as the body tries to cool itself." << endl;
        cout << "Certain Cancers : Some types of cancer, particularly lymphomas and leukemias, can cause fever as a symptom." << endl;
        cout << "Post - Surgery : Fever can be a normal response to surgery as part of the body's healing process." << endl;
        system("PAUSE");

    }
    else if (symptom == "cough") {
        cout << "The health problems that might exhibit cough symptoms:" << endl;
        cout << "1)Allergies" << endl;
        cout << "2)Asthma" << endl;
        cout << "3)Gastroesophageal Reflux Disease (GERD): GERD can cause stomach acid to flow back into the esophagus, leading to irritation and a chronic cough, especially when lying down." << endl;
        cout << "4)Chronic Obstructive Pulmonary Disease (COPD): COPD, including conditions like chronic bronchitis and emphysema, can cause a persistent cough, often accompanied by shortness of breath." << endl;
        cout << "5)Environmental Factors" << endl;
        cout << "6)Medications: Some medications, particularly ACE inhibitors used to treat high blood pressure, can cause a chronic dry cough as a side effect." << endl;
        cout << "7)Lung Diseases" << endl;
        cout << "8)Psychological Factors: In some cases, psychological factors or stress can lead to a chronic cough." << endl;
        cout << "If your cough symptom is serius, I would like to recommend you to consult a doctor." << endl;
        system("PAUSE");

    }
    else if (symptom == "others")
        cout << "Your symptoms seem to be vague. For a correct diagnosis, kindly visit to us as soon as possible. People often say that prevention is preferable to treatment!" << endl;

    else
        cout << "Thank you for using our Medical Consultation System. Take care!" << endl;
}
void registerpatient()
{
    const int maxSize = 1000;
    patient patients[maxSize];
    int patientCount;


    cout << "The number of patients register: ";
    cin >> patientCount;

    if (patientCount <= maxSize)
    {
        for (int i = 1; i <= patientCount; i++) {
            cout << endl;
            cout << "Enter patient's ID (5-digits): ";
            cin >> patients[i].patientID;

            cout << "Enter patient's Name: ";
            cin.ignore();
            getline(cin, patients[i].name);

            cout << "Enter patient's age: ";
            cin >> patients[i].age;

            cout << "Enter patient's diagnosis: ";
            cin.ignore();
            getline(cin, patients[i].diagnosis);
            cout << endl;
            cout << "Do you confirm the patient's information? (y/n): ";
            char a;
            cin >> a;

            if (a == 'y' || a == 'Y') {
                cout << "The patient's information is saved." << endl;
            }
            else {
                cout << "Please do confirmation again." << endl;
                cout << endl;
                cout << "Which patient need to be changed? (Exp: first patient = 1)" << endl;
                cin >> i;
                cout << "Enter patient's ID (5-digits): ";
                cin >> patients[i].patientID;
                cout << "Enter patient's Name: ";
                cin.ignore();
                getline(cin, patients[i].name);
                cout << "Enter patient's age: ";
                cin >> patients[i].age;
                cout << "Enter patient's diagnosis: ";
                cin.ignore();
                getline(cin, patients[i].diagnosis);
                cout << endl;
            }

        }
    }
    else

    {
        cout << "Exceeds hospital capacity. Please adjust the number of patients." << endl;

    }

    system("cls");
    int i;
    int choice;
    cout << "Do you need to review patient's information ? (yes=1,no=2)" << endl;
    cin >> choice;
    if (choice == 1)
    {
        cout << "Patient Information:" << endl;
        cout << "-----------------------------------------" << endl;
        for (int i = 1; i <= patientCount; i++) {
            cout << i << ')' << "Patient ID: " << setprecision(5) << patients[i].patientID << endl;
            cout << "  Name: " << patients[i].name << endl;
            cout << "  Age: " << setprecision(2) << patients[i].age << endl;
            cout << "  Diagnosis: " << patients[i].diagnosis << endl;
            cout << "-----------------------------------------" << endl;
            cin.ignore();

            ofstream(outFile);
            outFile.open("PatientInformation.txt", ios::app);
            outFile << "Patient's Information:" << endl;
            outFile << setprecision(5) << patients[i].patientID << endl;
            outFile << "Name: " << patients[i].name << endl;
            outFile << "Age: " << setprecision(2) << patients[i].age << endl;
            outFile << "Diagnosis: " << patients[i].diagnosis << endl;
            outFile << "-----------------------------------------" << endl;
            outFile.close();
        }
    }
    else if (choice == 2)
    {
        cout << "Information are saved." << endl;
    }
    else
    {
        cout << "Invalid input. Please try again." << endl;
        cout << "Do you need to review patient's information ? (yes=1,no=2)" << endl;
        cin >> choice;
    }
}
void searchpatient()
{
    string k;

    cout << "Please enter the patient's ID (5-digits): ";
    getline(cin, k);

    ifstream inFile("PatientInformation.txt");

    if (!inFile) {
        cout << "Error! Could not open the file." << endl;
    }

    else {
        bool found = false;
        string title, patientID, name, age, diagnosis;

        getline(inFile, title);
        getline(inFile, patientID);
        getline(inFile, name);
        getline(inFile, age);
        inFile >> diagnosis;
        inFile.ignore();
        if (k == patientID) {
            found = true;
            cout << "Patient's Information: " << endl;
            cout << "------------------------------" << endl;
            cout << "ID:" << patientID << endl;
            cout << name << endl;
            cout << age << endl;
            cout << diagnosis << endl;

        }


        inFile.close();

        if (!found) {
            cout << "Patient not found." << endl;
        }


    }
}

// Function to save doctors' data to a file
void saveDoctorsToFile() {
    ofstream file("doctors.txt");
    if (file.is_open()) {
        for (int i = 0; i < totalDoctors; i++) {
            file << doctors[i].name << endl;
            file << doctors[i].specialization << endl;
            file << doctors[i].phoneNumber << endl;
            file << doctors[i].IDNum << endl;
            file << doctors[i].age << endl;
            file << doctors[i].available << endl;
        }
        file.close();
    }
    else
        cout << "Unable to open file." << endl;
}

// Function to load doctors' data from a file
void loadDoctorsFromFile() {
    ifstream file("doctors.txt");
    if (file.is_open()) {
        totalDoctors = 0;
        while (!file.eof() && totalDoctors < 100) {
            file >> doctors[totalDoctors].name;
            file >> doctors[totalDoctors].specialization;
            file >> doctors[totalDoctors].phoneNumber;
            file >> doctors[totalDoctors].IDNum;
            file >> doctors[totalDoctors].age;
            file >> doctors[totalDoctors].available;
            totalDoctors++;
        }
        file.close();
    }
    else
        cout << "Unable to open file." << endl;
}

void registerDoctor() {

    Doctor newDoctor;

    cout << "Enter doctor's name: " << endl;
    cin >> newDoctor.name;

    cout << "Enter doctor's specialization: " << endl;
    cin >> newDoctor.specialization;

    cout << "Enter doctor's phone numbers: " << endl;
    cin >> newDoctor.phoneNumber;

    cout << "Enter doctor's ID numbers: " << endl;
    cin >> newDoctor.IDNum;

    cout << "Enter doctor's age: " << endl;
    cin >> newDoctor.age;

    newDoctor.available = true;

    for (int i = 0; i < 100; i++) {
        if (doctors[i].name.empty()) {
            doctors[i] = newDoctor;
            totalDoctors++;
            cout << "Dr." << newDoctor.name << " has been registered successfully." << endl;
            break;
        }
    }
}

void updateDocDetails(string ID) {
    for (int i = 0; i < totalDoctors; i++) {
        if (doctors[i].IDNum == ID) {
            char response;
            do {
                int choice;
                cout << "Please choose whichs details to update for Dr. " << doctors[i].name << ":" << endl;
                cout << "1. Specialization" << endl;
                cout << "2. Phone Number" << endl;
                cout << "3. ID Number" << endl;
                cout << "4. Age" << endl;
                cout << "Enter your choice (1-4): ";
                cin >> choice;

                switch (choice) {
                case 1:
                    cout << "Enter new specialization: ";
                    cin >> doctors[i].specialization;
                    break;
                case 2:
                    cout << "Enter new phone number: ";
                    cin >> doctors[i].phoneNumber;
                    break;
                case 3:
                    cout << "Enter new ID number: ";
                    cin >> doctors[i].IDNum;
                    break;
                case 4:
                    cout << "Enter new age: ";
                    cin >> doctors[i].age;
                    break;
                default:
                    cout << "Invalid choice. No details will be updated." << endl;
                    break;
                }

                cout << "Do you want to update another details for Dr." << doctors[i].name << "?(Y/N)" << endl;
                cin >> response;
            } while (response == 'y' || response == 'Y');
            cout << "The details of Dr." << doctors[i].name << " had been updated successfully." << endl;
            return;
        }
        else
            cout << "Doctor with ID number " << ID << " is not found." << endl;
    }
}
void deleteDoctor(string ID) {
    for (int i = 0; i < 100; i++) {
        if (doctors[i].IDNum == ID) {
            for (int j = i; j < totalDoctors - 1; j++) {
                doctors[j] = doctors[j + 1];
            }
            totalDoctors--;
            cout << "Doctor with ID number of " << ID << " has been removed." << endl;
            return;
        }
        else
            cout << "Doctor with ID number " << ID << " is not found." << endl;
    }
}

void displayDoctors() {
    if (totalDoctors > 0) {
        cout << "List of Registered Doctors:" << endl;
        for (int i = 0; i < totalDoctors; i++) {
            cout << "Doctor" << i + 1 << ":";
            cout << "Name :" << doctors[i].name << endl;
            cout << "Specialization: " << doctors[i].specialization << endl;
            cout << "Phone Number: " << doctors[i].phoneNumber << endl;
            cout << "ID Number: " << doctors[i].IDNum << endl;
            cout << "Age: " << doctors[i].age << endl;
            cout << "-------------------------------------" << endl;
        }
    }
    else
        cout << "No doctors are registered." << endl;
    return;
}
void searchDoctor() {
    string query;
    bool found = false;
    cout << "Enter the name/specialization/ID Number(Either one):" << endl;
    cin >> query;

    cout << "Search Results:" << endl;
    for (int i = 0; i < totalDoctors; i++) {
        if (doctors[i].name == query || doctors[i].specialization == query ||
            doctors[i].IDNum == query) {
            cout << "Doctor " << i + 1 << ":" << endl;
            cout << "Name: " << doctors[i].name << endl;
            cout << "Specialization: " << doctors[i].specialization << endl;
            cout << "Phone Number: " << doctors[i].phoneNumber << endl;
            cout << "ID Number: " << doctors[i].IDNum << endl;
            cout << "Age: " << doctors[i].age << endl;
            cout << "-----------------------------------" << endl;
            found = true;
        }
    }

    if (!found) {
        cout << "No matching doctors found." << endl;
    }
}

void allocateDoctorToEmergency() {
    bool found = false;
    for (int i = 0; i < totalDoctors; i++) {
        if (doctors[i].available) {
            // Assign the doctor to the emergency department
            doctors[i].available = false; // change the doctor availability to no
            cout << "Dr. " << doctors[i].name << " has been allocated to the emergency." << endl;
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "No available doctors for the emergency." << endl;
    }
}

void allocateDoctorToSpecialization(string specialization) {
    bool found = false;

    for (int i = 0; i < totalDoctors; i++) {
        if (doctors[i].available && doctors[i].specialization == specialization) {
            doctors[i].available = false; // change the doctor status to not available
            cout << "Dr. " << doctors[i].name << " has been allocated to " << specialization << "." << endl;
            found = true;
            break;
        }

    }
    if (!found) {
        cout << "No available doctors with the specified specialty." << endl;
    }
}
bool isDoctorAvailable(string ID) {
    for (int i = 0; i < totalDoctors; i++) {
        if (doctors[i].IDNum == ID) {
            return doctors[i].available;
        }
    }
    return false;
}

// Function to admit a patient to a ward
void admitpatient() {
    int wardnumber;
    cout << "Enter the ward number (1-" << maximumnumberofwards << "): ";
    cin >> wardnumber;

    if (wardnumber >= 1 && wardnumber <= maximumnumberofwards) {
        if (wards[wardnumber - 1].patientCount < maximumpatientsperward) {
            cout << "Enter patient name: ";
            cin.ignore();
            getline(cin, wards[wardnumber - 1].patients[wards[wardnumber - 1].patientCount].name);
            cout << "Enter patient age: ";
            cin >> wards[wardnumber - 1].patients[wards[wardnumber - 1].patientCount].age;
            wards[wardnumber - 1].patientCount++;

            cout << "Patient admitted successfully to Ward " << wardnumber << "." << endl;
            occupied++;
        }
        else {
            cout << "Ward " << wardnumber << " is full. Cannot admit more patients." << endl;
        }
    }
    else {
        cout << "Invalid ward number. Please choose a valid ward." << endl;
    }
}

// Function to display the status of all wards
void displaywardstatus() {
    if (occupied <= 0) {
        return;
    }
    cout << "Hospital Ward Status:" << endl;

    for (int i = 0; i < occupied; i++)
    {
        cout << "Ward " << (i + 1) << " (" << wards[i].patientCount << " patients):" << endl;
        for (int j = 0; j < wards[i].patientCount; j++)
        {
            cout << "  Patient Name: " << wards[i].patients[j].name << endl;
            cout << "  Age: " << wards[i].patients[j].age << endl;
            cout << "-------------------" << endl;
        }
    }
}

// Function to discharge a patient from a ward
void dischargepatient() {
    int wardnumber;
    cout << "Enter the ward number to discharge from (1-" << maximumnumberofwards << "): ";
    cin >> wardnumber;

    if (wardnumber >= 1 && wardnumber <= maximumnumberofwards) {
        if (wards[wardnumber - 1].patientCount > 0) {
            cout << "Enter the patient index to discharge (1-" << (wards[wardnumber - 1].patientCount - 1) + 1 << "): ";
            int patientIndex;
            cin >> patientIndex;

            if (patientIndex >= 0 && patientIndex < wards[wardnumber - 1].patientCount) {
                for (int i = patientIndex; i < wards[wardnumber - 1].patientCount - 1; i++) {
                    wards[wardnumber - 1].patients[i] = wards[wardnumber - 1].patients[i + 1];
                }
                wards[wardnumber - 1].patientCount--;

                cout << "Patient discharged from Ward " << wardnumber << "." << endl;
                occupied--;
            }
            else {
                cout << "Invalid patient index. Please enter a valid index." << endl;
            }
        }
        else {
            cout << "Ward " << wardnumber << " is empty. No patients to discharge." << endl;
        }
    }
    else {
        cout << "Invalid ward number. Please choose a valid ward." << endl;
    }
}

// Function to add a new medicine to the list
void addmedicine() {
    if (medicinecount < maximumnumberofmedicine) {
        string name;
        int quantity;
        double price;

        cout << "Enter medicine name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter quantity: ";
        cin >> quantity;
        cout << "Enter price per unit: ";
        cin >> price;

        medications[medicinecount].name = name;
        medications[medicinecount].quantity = quantity;
        medications[medicinecount].price = price;

        medicinecount++;

        cout << "Medicine added successfully." << endl;
    }
    else {
        cout << "Maximum number of medicines reached." << endl;
    }
}

// Function to display the list of medicines
void displaymedicine() {
    cout << "Medicine List:" << endl;
    for (int i = 0; i < medicinecount; i++) {
        cout << "Name: " << medications[i].name << endl;
        cout << "Quantity: " << medications[i].quantity << endl;
        cout << "Price per unit: $" << medications[i].price << endl;
        cout << "-------------------" << endl;
    }
}

// Function to search the entire medicine by using name
void searchmedicinebyname() {
    string searchName;
    cout << "Enter the medicine name to search for: ";
    cin.ignore();
    getline(cin, searchName);

    bool found = false;
    for (int i = 0; i < medicinecount; i++) {
        if (medications[i].name == searchName) {
            cout << "Medicine found" << endl;
            cout << "Name: " << medications[i].name << endl;
            cout << "Quantity: " << medications[i].quantity << endl;
            cout << "Price per unit: $" << medications[i].price << endl;
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "Medicine not found." << endl;
    }
}

// Function to delete a medicine by name
void deletemedicine() {
    string deleteName;
    cout << "Enter the medicine name to delete: ";
    cin.ignore();
    getline(cin, deleteName);

    for (int i = 0; i < medicinecount; i++) {
        if (medications[i].name == deleteName) {
            for (int j = i; j < medicinecount - 1; j++) {
                medications[j] = medications[j + 1];
            }
            medicinecount--;

            cout << "Medicine deleted successfully." << endl;
            return;
        }
    }

    cout << "Medicine not found." << endl;
}

// Function to sell a medicine
void sellmedicine() {
    string sellname;
    int sellquantity;

    cout << "Enter medicine name to sell: ";
    cin.ignore();
    getline(cin, sellname);

    for (int i = 0; i < medicinecount; i++) {
        if (medications[i].name == sellname) {
            cout << "Enter quantity to sell: ";
            cin >> sellquantity;

            if (sellquantity <= medications[i].quantity) {
                medications[i].quantity -= sellquantity;
                cout << "Sale successful. Total cost: $" << (medications[i].price * sellquantity) << endl;
            }
            else {
                cout << "Not enough stock for the sale." << endl;
            }

            return;
        }
    }

    cout << "Medication not found." << endl;
}
// Function to calculate the total bill amount
double calculatebill(int roomcharge, int medicinecharge, int servicecharge)
{
    return roomcharge + medicinecharge + servicecharge;
}

//Function for main menu display
void displaymenu(){
    cout << " Welcome to ABC Hospital Management System " << endl;
    cout << " Main Menu " << endl;
    cout << " 1. Medical Conslutation Module" << endl;
    cout << " 2. Patient Information Storing Module" << endl;
    cout << " 3. Patient Information Searching Module" << endl;
    cout << " 4. Regristration, Update and Deletion of a Doctor Module" << endl;
    cout << " 5. Doctor Information Searching Module" << endl;
    cout << " 6. Allocation of Doctors Module" << endl;
    cout << " 7. Admission, Discharge and Ward Management Module " << endl;
    cout << " 8. Pharmacy Dispensary Module" << endl;
    cout << " 9. Bill counting module" << endl;
    cout << " 10. Exit the System" << endl;
    cout << " Please enter your choice: ";
}
int main()
{
    int choices, choice1, choice2, choice3, choice4, choice5, choice6, choice7, choice8, choice9;
    char decision1, decision2, decision3, decision4, decision5, decision6, decision7, decision8, decision9;
    string patientname;
    int roomcharge, medicinecharge, servicecharge;
    string doctorID;
    string specialization;

    displaymenu();
    cin >> choices;

    while (choices >= 1 || choices <= 10)
    {
        if (choices == 1)
        {
            medicalconsultation();
            cout << "Do you have another sypmtom? (Y/N): ";
            cin >> decision1;
            if (decision1 == 'y' || decision1 == 'Y')
            {
                medicalconsultation();
            }
            else if (decision1 == 'n' || decision1 == 'N')
            {
                cout << "Back to the main menu" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                displaymenu();
                cin >> choices;
            }
            else
            {
                cout << "Invalid input. Please try again." << endl;
                cout << "Do you have another symptom? (Y/N)" << endl;
                cin >> decision1;
            }
        }
        else if (choices == 2)
        {
            registerpatient();
            cout << "Do you have another patients to register? (Y/N): ";
            cin >> decision2;
            if (decision2 == 'y' || decision2 == 'Y')
            {
                registerpatient();
            }
            else if (decision2 == 'n' || decision2 == 'N')
            {
                cout << "Back to the main menu" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                displaymenu();
                cin >> choices;
            }
            else
            {
                cout << "Invalid input. Please try again." << endl;
                cout << "Do you have another patient to register? (Y/N)" << endl;
                cin >> decision2;
            }
        }
        else if (choices == 3)
        {
            searchpatient();
            cout << "Do you have another patients to register? (Y/N): ";
            cin >> decision3;
            if (decision3 == 'y' || decision3 == 'Y')
            {
                searchpatient();
            }
            else if (decision3 == 'n' || decision3 == 'N')
            {
                cout << "Back to the main menu" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                displaymenu();
                cin >> choices;
            }
            else
            {
                cout << "Invalid input. Please try again." << endl;
                cout << "Do you have another patient to register? (Y/N)" << endl;
                cin >> decision3;
            }
        }
        else if (choices == 4)
        {
            do {
                loadDoctorsFromFile();
                cout << "Regristration, Update and Deletion of a Doctor Module" << endl;
                cout << "1. Register a Doctor" << endl;
                cout << "2. Update Doctor Details" << endl;
                cout << "3. Delete Doctor Details" << endl;
                cout << "4. Main Menu" << endl;
                cout << "Please enter your choice (1-4): ";
                cin >> choice4;

                switch (choice4) {
                case 1:
                    registerDoctor();
                    break;
                case 2:
                    cout << "Please enter the ID of the doctor you want to update: ";
                    cin >> doctorID;
                    updateDocDetails(doctorID);
                    break;
                case 3:
                    cout << "Please enter the ID of the doctor you want to delete: ";
                    cin >> doctorID;
                    deleteDoctor(doctorID);
                    break;
                case 4:
                    cout << "Exiting the module. Back to the main menu" << endl;
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }

                saveDoctorsToFile();
                cout << "Do you have other actions to carry out? (Y/N): ";
                cin >> decision4;
                if (decision4 == 'n' || decision4 == 'N')
                    return 0;
            } while (choice4 != 5 || (decision4 == 'y' || decision4 == 'Y'));
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            displaymenu();
            cin >> choices;
        }
        else if (choices == 5)
        {
            do {
                cout << "Doctor Management System (Module 2)" << endl;
                cout << "1. Display Registered Doctors" << endl;
                cout << "2. Search for a Doctor" << endl;
                cout << "3. Exit" << endl;
                cout << "Please enter your choice (1-3): ";
                cin >> choice5;

                switch (choice5) {
                case 1:
                    displayDoctors();
                    break;
                case 2:
                    searchDoctor();
                    break;
                case 3:
                    cout << "Exiting the module. Back to the main menu" << endl;
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }

                cout << "Do you have other actions to carry out? (Y/N): ";
                cin >> decision5;
                if (decision5 == 'n' || decision5 == 'N')
                    return 0;
            } while (choice5 != 3 || (decision5 == 'Y' || decision5 == 'y'));

            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            displaymenu();
            cin >> choices;
        }

        else if (choices == 6)
        {
            do {
                cout << "Doctor Management System (Module 3)" << endl;
                cout << "1. Allocate Doctor to Emergency" << endl;
                cout << "2. Allocate Doctor by Specialization" << endl;
                cout << "3. Main Menu" << endl;
                cout << "Please enter your choice (1-3): ";
                cin >> choice6;

                switch (choice6) {
                case 1:
                    allocateDoctorToEmergency();
                    break;
                case 2:
                    cout << "Enter specialization: ";
                    cin >> specialization;
                    allocateDoctorToSpecialization(specialization);
                    break;
                case 3:
                    cout << "Exiting the module. Back to the main menu" << endl;
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
                }

                cout << "Do you have other actions to carry out? (Y/N): ";
                cin >> decision6;
                if (decision6 == 'n' || decision6 == 'N')
                    return 0;
            } while (choice6 != 3 || (decision6 == 'Y' || decision6 == 'y'));

            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            cout << "*********************************************************************************************" << endl;
            displaymenu();
            cin >> choices;

        }
        else if (choices == 7)
        {
            // Initialize wards
            for (int i = 0; i < maximumnumberofwards; i++) {
                wards[i].patientCount = 0;
            }


            cout << "Admission, Discharge and Ward Management Module" << endl;
            cout << "1. Admissions of patients" << endl;
            cout << "2. Patients' discharge" << endl;
            cout << "3. Ward status display" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice7;

            while (choice7 >= 1 || choice7 <= 4)
            {
                if (choice7 == 1)
                {
                    admitpatient();
                    cout << "Do you want to admit another patient?(Y/N)" << endl;
                    cin >> decision7;
                    if (decision7 == 'Y' || decision7 == 'y')
                    {
                        admitpatient();
                        cout << "Do you want to admit another patient?(Y/N)" << endl;
                    }
                    else if (decision7 == 'N' || decision7 == 'n')
                    {
                        cout << "Admission, Discharge and Ward Management Module" << endl;
                        cout << "1. Admissions of patients" << endl;
                        cout << "2. Patients' discharge" << endl;
                        cout << "3. Ward status display" << endl;
                        cout << "4. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice7;
                    }
                    else
                    {
                        cout << "Invalid input. Please try again." << endl;
                        cout << "Admission, Discharge and Ward Management Module" << endl;
                        cout << "1. Admissions of patients" << endl;
                        cout << "2. Patients' discharge" << endl;
                        cout << "3. Ward status display" << endl;
                        cout << "4. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice7;
                    }
                }

                else if (choice7 == 2)
                {
                    dischargepatient();
                    cout << "Do you want to discharge another patient?(Y/N)" << endl;
                    cin >> decision7;
                    if (decision7 == 'Y' || decision7 == 'y')
                    {
                        dischargepatient();
                        cout << "Do you want to discharge another patient?(Y/N)" << endl;
                    }
                    else if (decision7 == 'N' || decision7 == 'n')
                    {
                        cout << "Admission, Discharge and Ward Management Module" << endl;
                        cout << "1. Admissions of patients" << endl;
                        cout << "2. Patients' discharge" << endl;
                        cout << "3. Ward status display" << endl;
                        cout << "4. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice7;
                    }
                    else
                    {
                        cout << "Invalid input. Please try again." << endl;
                        cout << "Do you want to discharge another patient?(Y/N)" << endl;
                        cin >> decision7;
                    }
                }

                else if (choice7 == 3)
                {
                    displaywardstatus();
                    cout << "Admission, Discharge and Ward Management Module" << endl;
                    cout << "1. Admissions of patients" << endl;
                    cout << "2. Patients' discharge" << endl;
                    cout << "3. Ward status display" << endl;
                    cout << "4. Exit" << endl;
                    cout << "Enter your choice: ";
                    cin >> choice7;
                }
                else if (choice7 == 4)
                {
                    cout << "Exiting the module" << endl;
                    cout << "Do you have other actions to carry out? (Y/N): ";
                    cin >> decision7;
                    if (decision7 == 'y' || decision7 == 'Y')
                    {
                        cout << "Admission, Discharge and Ward Management Module" << endl;
                        cout << "1. Admissions of patients" << endl;
                        cout << "2. Patients' discharge" << endl;
                        cout << "3. Ward status display" << endl;
                        cout << "4. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice7;
                    }
                    if (decision7 == 'n' || decision7 == 'N')
                        return 0;
                }

                else
                {
                    cout << "Invalid choice. Please try again." << endl;
                    cout << "Admission, Discharge and Ward Management Module" << endl;
                    cout << "1. Admissions of patients" << endl;
                    cout << "2. Patients' discharge" << endl;
                    cout << "3. Ward status display" << endl;
                    cout << "4. Back to main menu" << endl;
                    cout << "Enter your choice: ";
                    cin >> choice7;
                }
            }
        }

        else if (choices == 8)
        {
            cout << "Pharmacy Dispensary Module:" << endl;
            cout << "1. Medicine adding" << endl;
            cout << "2. Medicine display" << endl;
            cout << "3. Medicine searching" << endl;
            cout << "4. Medicine deletion" << endl;
            cout << "5. Medicine selling" << endl;
            cout << "6. Back to main menu" << endl;
            cout << "Enter your choice: ";
            cin >> choice8;

            while (choice8 >= 1 || choice8 <= 6)
            {
                if (choice8 == 1)
                {
                    addmedicine();
                    cout << "Do you want to add another medicine?(Y/N)" << endl;
                    cin >> decision8;
                    if (decision8 == 'Y' || decision8 == 'y')
                    {
                        addmedicine();
                        cout << "Do you want to add another medicine?(Y/N)" << endl;
                    }
                    else if (decision8 == 'N' || decision8 == 'n') {
                        cout << "Pharmacy Dispensary Module:" << endl;
                        cout << "1. Medicine adding" << endl;
                        cout << "2. Medicine display" << endl;
                        cout << "3. Medicine searching" << endl;
                        cout << "4. Medicine deletion" << endl;
                        cout << "5. Medicine selling" << endl;
                        cout << "6. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice8;
                    }
                    else {
                        cout << "Invalid input. Please try again" << endl;
                        cout << "Do you want to add another nedicine?(Y/N)" << endl;
                        cin >> decision8;
                    }
                }

                else if (choice8 == 2)
                {
                    displaymedicine();
                    cout << "Pharmacy Dispensary Module:" << endl;
                    cout << "1. Medicine adding" << endl;
                    cout << "2. Medicine display" << endl;
                    cout << "3. Medicine searching" << endl;
                    cout << "4. Medicine deletion" << endl;
                    cout << "5. Medicine selling" << endl;
                    cout << "6. Exit" << endl;
                    cout << "Enter your choice: ";
                    cin >> choice8;
                }

                else if (choice8 == 3)
                {
                    searchmedicinebyname();
                    cout << "Do you want to search another medicine?(Y/N)" << endl;
                    cin >> decision8;
                    if (decision8 == 'Y' || decision8 == 'y')
                    {
                        searchmedicinebyname();
                        cout << "Do you want to search another medicine?(Y/N)" << endl;
                    }
                    else if (decision8 == 'N' || decision8 == 'n')
                    {
                        cout << "Pharmacy Dispensary Module:" << endl;
                        cout << "1. Medicine adding" << endl;
                        cout << "2. Medicine display" << endl;
                        cout << "3. Medicine searching" << endl;
                        cout << "4. Medicine deletion" << endl;
                        cout << "5. Medicine selling" << endl;
                        cout << "6. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice8;
                    }
                    else
                    {
                        cout << "Invalid input. Please try again" << endl;
                        cout << "Do you want to add another nedicine?(Y/N)" << endl;
                        cin >> decision8;
                    }
                }

                else if (choice8 == 4)
                {
                    deletemedicine();
                    cout << "Do you want to search another medicine?(Y/N)" << endl;
                    cin >> decision8;
                    if (decision8 == 'Y' || decision8 == 'y')
                    {
                        deletemedicine();
                        cout << "Do you want to search another medicine?(Y/N)" << endl;
                    }
                    else if (decision8 == 'N' || decision8 == 'n')
                    {
                        cout << "Pharmacy Dispensary Module:" << endl;
                        cout << "1. Medicine adding" << endl;
                        cout << "2. Medicine display" << endl;
                        cout << "3. Medicine searching" << endl;
                        cout << "4. Medicine deletion" << endl;
                        cout << "5. Medicine selling" << endl;
                        cout << "6. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice8;
                    }
                    else
                    {
                        cout << "Invalid input. Please try again" << endl;
                        cout << "Do you want to add another nedicine?(Y/N)" << endl;
                        cin >> decision8;
                    }
                }

                else if (choice8 == 5)
                {
                    sellmedicine();
                    cout << "Do you want to search another medicine?(Y/N)" << endl;
                    cin >> decision8;
                    if (decision8 == 'Y' || decision8 == 'y')
                    {
                        sellmedicine();
                        cout << "Do you want to search another medicine?(Y/N)" << endl;
                    }
                    else if (decision8 == 'N' || decision8 == 'n')
                    {
                        cout << "Pharmacy Dispensary Module:" << endl;
                        cout << "1. Medicine adding" << endl;
                        cout << "2. Medicine display" << endl;
                        cout << "3. Medicine searching" << endl;
                        cout << "4. Medicine deletion" << endl;
                        cout << "5. Medicine selling" << endl;
                        cout << "6. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice8;
                    }
                    else
                    {
                        cout << "Invalid input. Please try again" << endl;
                        cout << "Do you want to add another nedicine?(Y/N)" << endl;
                        cin >> decision8;
                    }
                }

                else if (choice8 == 6)
                {
                    cout << "Exiting the module" << endl;
                    cout << "Do you have other actions to carry out? (Y/N): ";
                    cin >> decision8;
                    if (decision8 == 'y' || decision8 == 'Y')
                    {
                        cout << "Pharmacy Dispensary Module:" << endl;
                        cout << "1. Medicine adding" << endl;
                        cout << "2. Medicine display" << endl;
                        cout << "3. Medicine searching" << endl;
                        cout << "4. Medicine deletion" << endl;
                        cout << "5. Medicine selling" << endl;
                        cout << "6. Exit" << endl;
                        cout << "Enter your choice: ";
                        cin >> choice8;
                    }
                    if (decision8== 'n' || decision8 == 'N')
                        return 0;
                }

                else if (choice8 < 1 || choice8 > 6)
                {
                    cout << "Invalid choice. Please try again." << endl;
                    cout << "Pharmacy Dispensary Module:" << endl;
                    cout << "1. Medicine adding" << endl;
                    cout << "2. Medicine display" << endl;
                    cout << "3. Medicine searching" << endl;
                    cout << "4. Medicine deletion" << endl;
                    cout << "5. Medicine selling" << endl;
                    cout << "6. Back to main menu" << endl;
                    cout << "Enter your choice: ";
                    cin >> choice8;
                }
            }
        }
        else if (choices == 9)
        {
            // Input patient name
            cout << "Enter patient's name: ";
            cin.ignore();
            getline(cin, patientname);

            cout << "Enter room charge: $";// Input room charge
            cin >> roomcharge;
            cout << "Enter medication charge: $"; // Input medication charge
            cin >> medicinecharge;
            cout << "Enter service charge: $";// Input service charge
            cin >> servicecharge;

            double totalbill = calculatebill(roomcharge, medicinecharge, servicecharge);// Calculate the total bill amount

            // Display the bill details
            cout << "\nPatient Name: " << patientname << endl;
            cout << "Room Charge: $" << roomcharge << endl;
            cout << "Medication Charge: $" << medicinecharge << endl;
            cout << "Service Charge: $" << servicecharge << endl;
            cout << "-------------------" << endl;
            cout << "Total Bill: $" << totalbill << endl;

            cout << "Do you want to calculate another bill?(Y/N)" << endl;
            cin >> decision9;
            if (decision9 == 'Y' || decision9 == 'y')
            {
                cout << "Enter patient's name: ";
                cin.ignore();
                getline(cin, patientname);

                cout << "Enter room charge: $";// Input room charge
                cin >> roomcharge;
                cout << "Enter medication charge: $"; // Input medication charge
                cin >> medicinecharge;
                cout << "Enter service charge: $";// Input service charge
                cin >> servicecharge;

                double totalbill = calculatebill(roomcharge, medicinecharge, servicecharge);// Calculate the total bill amount

                // Display the bill details
                cout << "\nPatient Name: " << patientname << endl;
                cout << "Room Charge: $" << roomcharge << endl;
                cout << "Medication Charge: $" << medicinecharge << endl;
                cout << "Service Charge: $" << servicecharge << endl;
                cout << "-------------------" << endl;
                cout << "Total Bill: $" << totalbill << endl;

            }
            else if (decision9 == 'N' || decision9 == 'n')
            {
                cout << "Back to the main menu" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                cout << "*********************************************************************************************" << endl;
                displaymenu();
                cin >> choices;
            }
            else
            {
                cout << "Invalid input. Please try again" << endl;
                cout << "Do you want to calculate another bill?(Y/N)" << endl;
                cin >> decision9;
            }
        }
        else if (choices == 10)
        {
            cout << " Thanks for using the system. Have A Nice Day." << endl;
            return 0;
        }
        else (choices < 1 || choices >10);
        {
            cout << "Invalid choice. Please try again" << endl;
            displaymenu();
            cin >> choices;
        }
    }

    system("pause");
    return 0;
}