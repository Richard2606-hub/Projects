#include<iostream>
using namespace std;

int main()
{
	//Declare variables
	int a1, a2, a3, n1, n2, n3, i, j, k, hcf1, hcf2, hcf3, N, Y;
	int m1, m2, m3, mi1, mi2, mi3;

	//Asking for input three remainders and three modulos
	cout << "Please enter three remainders. \n";
	cin >> a1 >> a2 >> a3;
	cout << "Please enter three modulos. \n";
	cin >> n1 >> n2 >> n3;

	//Check for the input value of n1, n2, and n3.
	if (n1 <= 0 || n2 <= 0 || n3 <= 0)
	{
		cout << "Invalid input for modulo.";
		return 0;
	}

	//Check for the highest common factor (hcf) for the following pairs: (n1, n2), (n1, n3), (n2, n3).
	for (i = 1; i < n1 || i < n2; i++)
	{
		if (n1 % i == 0 && n2 % i == 0)
			hcf1 = i;
	}
	for (j = 1; j < n1 || j < n3; j++)
	{
		if (n1 % j == 0 && n3 % j == 0)
			hcf2 = j;
	}
	for (k = 1; k < n2 || k < n3; k++)
	{
		if (n2 % k == 0 && n3 % k == 0)
			hcf3 = k;
	}

	//Check pairwise co-prime
	if (hcf1 != 1 || hcf2 != 1 || hcf3 != 1)
	{
		cout << n1 << " " << n2 << " " << n3 << " " << "are not pairwise co-prime." << endl;
		return 0;
	}

	//Output of system congruences 
	cout << " the system of congruences to be solved is: " << endl;
	cout << "x % " << n1 << " = " << a1 << ";" << endl;
	cout << "x % " << n2 << " = " << a2 << ";" << endl;
	cout << "x % " << n3 << " = " << a3 << ";" << endl;

	//Calculate the value of N, m1, m2, m3, mi1, mi2, and mi3
	N = n1 * n2 * n3;
	m1 = N / n1;
	m2 = N / n2;
	m3 = N / n3;
	mi1 = m1 % n1;
	mi2 = m2 % n2;
	mi3 = m3 % n3;

	//Calculate the value of Y
	Y = (a1 * m1 * mi1) + (a2 * m2 * mi2) + (a3 * m3 * mi3);
	Y %= N;

	cout << " The system of congruences has the solution " << Y << " modulo " << N << endl;

	system("pause");
	return 0;
}