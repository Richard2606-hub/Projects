import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Medicine {
	private String name, manufacturer, expiryDate;
	private int cost, count;
	
	public Medicine() {
		
	}
	
	public Medicine(String name, String manufacturer, String expiryDate, int cost, int count) {
		this.name = name;
		this.manufacturer = manufacturer;
		this.expiryDate = expiryDate;
		this.cost = cost;
		this.count = count;
	}
	
	public String getName() { 
		return name; 
	}
    
	public void setName(String name) {
		this.name = name; 
	}
    
    public String getManufacturer() { 
    	return manufacturer; 
    }
    
    public void setManufacturer(String manufacturer) { 
    	this.manufacturer = manufacturer; 
    }
    
    public String getExpiryDate() { 
    	return expiryDate; 
    }
    
    public void setExpiryDate(String expiryDate) {
    	this.expiryDate = expiryDate;
    }
    public int getCost() { 
    	return cost; 
    }
    
    public void setCost(int cost) { 
    	this.cost = cost; 
    }
    
    public int getCount() { 
    	return count; 
    }
    
    public void setCount(int count) { 
    	this.count = count; 
    }
    
 // Method to check if the staff already exists
    private boolean isDuplicate(ArrayList<Medicine> medicines) {
        for (Medicine medicine : medicines) {
            if (medicine.getName().equals(this.name)) {
                return true;
            }
        }
        return false;
    }

    
    public VBox newMedicine(ArrayList<Medicine> medicines) {
        Text object = new Text("Medicine");
        object.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));

        VBox content = new VBox();
        Label Name = new Label("Name of Medicine: ");
        TextField txtA = new TextField();
        Name.setPrefWidth(250);

        Label Manufacturer = new Label("Manufacturer of Medicine: ");
        TextField txtB = new TextField();
        Manufacturer.setPrefWidth(250);

        Label Expiry_Date = new Label("Expiry Date of Medicine: ");
        TextField txtC = new TextField();
        Expiry_Date.setPrefWidth(250);

        Label Cost = new Label("Cost of Medicine per unit: ");
        TextField txtD = new TextField();
        Cost.setPrefWidth(250);

        Label Number = new Label("Number of unit for medicine: ");
        TextField txtE = new TextField();
        Number.setPrefWidth(250);

        Button submitBtn = new Button("Submit");
        submitBtn.setPrefWidth(150);
        submitBtn.setOnAction(e -> {
            String nameInput = txtA.getText().trim();
            String manufacturerInput = txtB.getText().trim();
            String expiryDateInput = txtC.getText().trim();
            String costInput = txtD.getText().trim();
            String countInput = txtE.getText().trim();

            // Validate input
            if (nameInput.isEmpty() || manufacturerInput.isEmpty() || expiryDateInput.isEmpty() ||
                costInput.isEmpty() || countInput.isEmpty()) {
                content.getChildren().add(new Text("Error: All fields must be filled in."));
                return;
            }

            try {
                this.name = nameInput;
                this.manufacturer = manufacturerInput;
                this.expiryDate = expiryDateInput;
                this.cost = Integer.parseInt(costInput);
                this.count = Integer.parseInt(countInput);

                // Check for duplicate ID
                if (isDuplicate(medicines)) {
                    content.getChildren().add(new Text("Error: Medicine already exists."));
                    return;
                }

                // Output to file using try-with-resources
                try (FileWriter fw = new FileWriter("Medicine.txt", true);
                     PrintWriter outputFile = new PrintWriter(fw)) {

                    outputFile.println(manufacturer);
                    outputFile.println(name);
                    outputFile.println(expiryDate);
                    outputFile.println(Integer.toString(cost));
                    outputFile.println(Integer.toString(count));
                    outputFile.println(""); // Adding a blank line for separation

                } catch (IOException e1) {
                    e1.printStackTrace();
                    content.getChildren().add(new Text("Error: Unable to write to file."));
                    return;
                }

                // Add the staff to the list and display success message
                medicines.add(this);
                content.getChildren().add(new Text("Added successfully!"));

            } catch (NumberFormatException ex) {
                content.getChildren().add(new Text("Error: cost and number must be an integer."));
            }
        });

        // Layout setup
        HBox rowA = new HBox(Name, txtA);
        HBox rowB = new HBox(Manufacturer, txtB);
        HBox rowC = new HBox(Expiry_Date, txtC);
        HBox rowD = new HBox(Cost, txtD);
        HBox rowE = new HBox(Number, txtE);

        content.getChildren().addAll(object, new Text(""), rowA, rowB, rowC, rowD, rowE, submitBtn);
        content.setSpacing(10);
        rowA.setAlignment(Pos.CENTER);
        rowB.setAlignment(Pos.CENTER);
        rowC.setAlignment(Pos.CENTER);
        rowD.setAlignment(Pos.CENTER);
        rowE.setAlignment(Pos.CENTER);
        content.setAlignment(Pos.CENTER);

        return content;
    }

    // Method to show staff info in a GridPane
    public GridPane findMedicine(GridPane pane, int row) {
        pane.add(new Text(name), 0, row);
        pane.add(new Text(manufacturer), 1, row);
        pane.add(new Text(expiryDate), 2, row);
        pane.add(new Text(Integer.toString(cost)), 3, row);
        pane.add(new Text(Integer.toString(count)), 4, row);
        return pane;
    }
}


