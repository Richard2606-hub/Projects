import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Patient {
    private String id, name, disease, sex, admitStatus;
    private int age;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDisease() { return disease; }
    public void setDisease(String disease) { this.disease = disease; }
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }
    public String getAdmitStatus() { return admitStatus; }
    public void setAdmitStatus(String admitStatus) { this.admitStatus = admitStatus; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    
	public Patient() {
		
	}
	
	public Patient(String id, String name, String disease, String sex, String admitStatus, int age) {
		this.id = id;
		this.name = name;
		this.disease = disease;
		this.sex = sex;
		this.admitStatus = admitStatus;
		this.age = age;
	}

    // Method to check if the patient already exists
    private boolean isDuplicate(ArrayList<Patient> patients) {
        for (Patient patient : patients) {
            if (patient.getId().equals(this.id)) {
                return true;
            }
        }
        return false;
    }

    // Method to create the new patient form
    public VBox newPatient(ArrayList<Patient> patients) {
        Text object = new Text("Patient");
        object.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));

        VBox content = new VBox();
        Label ID = new Label("Enter ID: ");
        TextField txtA = new TextField();
        ID.setPrefWidth(250);

        Label Name = new Label("Enter Name: ");
        TextField txtB = new TextField();
        Name.setPrefWidth(250);

        Label DI = new Label("Enter Disease: ");
        TextField txtC = new TextField();
        DI.setPrefWidth(250);

        Label Sex = new Label("Enter Sex: ");
        TextField txtD = new TextField();
        Sex.setPrefWidth(250);

        Label AS = new Label("Enter Admit Status: ");
        TextField txtE = new TextField();
        AS.setPrefWidth(250);

        Label Age = new Label("Enter Age: ");
        TextField txtF = new TextField();
        Age.setPrefWidth(250);

        Button submitBtn = new Button("Submit");
        submitBtn.setPrefWidth(150);
        submitBtn.setOnAction(e -> {
            String idInput = txtA.getText().trim();
            String nameInput = txtB.getText().trim();
            String diseaseInput = txtC.getText().trim();
            String sexInput = txtD.getText().trim();
            String admitStatusInput = txtE.getText().trim();
            String ageInput = txtF.getText().trim();

            // Validate input
            if (idInput.isEmpty() || nameInput.isEmpty() || diseaseInput.isEmpty() ||
                sexInput.isEmpty() || admitStatusInput.isEmpty() || ageInput.isEmpty()) {
                content.getChildren().add(new Text("Error: All fields must be filled in."));
                return;
            }

            try {
                this.id = idInput;
                this.name = nameInput;
                this.disease = diseaseInput;
                this.sex = sexInput;
                this.admitStatus = admitStatusInput;
                this.age = Integer.parseInt(ageInput);

                // Check for duplicate ID
                if (isDuplicate(patients)) {
                    content.getChildren().add(new Text("Error: Patient with this ID already exists."));
                    return;
                }

                // Output to file using try-with-resources
                try (FileWriter fw = new FileWriter("Patient.txt", true);
                     PrintWriter outputFile = new PrintWriter(fw)) {

                    outputFile.println(id);
                    outputFile.println(name);
                    outputFile.println(disease);
                    outputFile.println(sex);
                    outputFile.println(admitStatus);
                    outputFile.println(age);
                    outputFile.println(""); // Adding a blank line for separation

                } catch (IOException e1) {
                    e1.printStackTrace();
                    content.getChildren().add(new Text("Error: Unable to write to file."));
                    return;
                }

                // Add the patient to the list and display success message
                patients.add(this);
                content.getChildren().add(new Text("Added successfully!"));

            } catch (NumberFormatException ex) {
                content.getChildren().add(new Text("Error: Age must be an integer."));
            }
        });

        // Layout setup
        HBox rowA = new HBox(ID, txtA);
        HBox rowB = new HBox(Name, txtB);
        HBox rowC = new HBox(DI, txtC);
        HBox rowD = new HBox(Sex, txtD);
        HBox rowE = new HBox(AS, txtE);
        HBox rowF = new HBox(Age, txtF);

        content.getChildren().addAll(object, new Text(""), rowA, rowB, rowC, rowD, rowE, rowF, submitBtn);
        content.setSpacing(10);
        rowA.setAlignment(Pos.CENTER);
        rowB.setAlignment(Pos.CENTER);
        rowC.setAlignment(Pos.CENTER);
        rowD.setAlignment(Pos.CENTER);
        rowE.setAlignment(Pos.CENTER);
        rowF.setAlignment(Pos.CENTER);
        content.setAlignment(Pos.CENTER);

        return content;
    }

    // Method to show patient info in a GridPane
    public GridPane showPatientInfo(GridPane pane, int row) {
        pane.add(new Text(id), 0, row);
        pane.add(new Text(name), 1, row);
        pane.add(new Text(disease), 2, row);
        pane.add(new Text(sex), 3, row);
        pane.add(new Text(admitStatus), 4, row);
        pane.add(new Text(Integer.toString(age)), 5, row);
        return pane;
    }
}