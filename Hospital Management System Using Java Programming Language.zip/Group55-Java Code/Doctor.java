import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Doctor {
    private String id;
    private String name;
    private String specialist;
    private String workTime;
    private String qualification;
    private int room;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecialist() { return specialist; }
    public void setSpecialist(String specialist) { this.specialist = specialist; }
    public String getWorkTime() { return workTime; }
    public void setWorkTime(String workTime) { this.workTime = workTime; }
    public String getQualification() { return qualification; }
    public void setQualification(String qualification) { this.qualification = qualification; }
    public int getRoom() { return room; }
    public void setRoom(int room) { this.room = room; }
    
    public Doctor(){
    	
    }
    
    public Doctor(String id, String name, String specialist, String workTime, String qualification, int room) {
		this.id = id;
		this.name = name;
		this.specialist = specialist;
		this.workTime = workTime;
		this.qualification = qualification;
		this.room = room;
	}
    

    // Method to check if the doctor already exists
    private boolean isDuplicate(ArrayList<Doctor> doctors) {
        for (Doctor doc : doctors) {
            if (doc.getId().equals(this.id)) {
                return true;
            }
        }
        return false;
    }

    // Method to create the new doctor form
    public VBox newDoctor(ArrayList<Doctor> doctors) {
        Text object = new Text("Doctor");
        object.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));

        VBox content = new VBox();
        Label ID = new Label("Enter ID: ");
        TextField txtA = new TextField();
        ID.setPrefWidth(250);

        Label Name = new Label("Enter Name: ");
        TextField txtB = new TextField();
        Name.setPrefWidth(250);

        Label SP = new Label("Enter Specialist: ");
        TextField txtC = new TextField();
        SP.setPrefWidth(250);

        Label WT = new Label("Enter Work Time: ");
        TextField txtD = new TextField();
        WT.setPrefWidth(250);

        Label QL = new Label("Enter Qualification: ");
        TextField txtE = new TextField();
        QL.setPrefWidth(250);

        Label Room = new Label("Enter Room No.: ");
        TextField txtF = new TextField();
        Room.setPrefWidth(250);

        Button submitBtn = new Button("Submit");
        submitBtn.setPrefWidth(150);
        submitBtn.setOnAction(e -> {
            String idInput = txtA.getText().trim();
            String nameInput = txtB.getText().trim();
            String specialistInput = txtC.getText().trim();
            String workTimeInput = txtD.getText().trim();
            String qualificationInput = txtE.getText().trim();
            String roomInput = txtF.getText().trim();

            // Validate input
            if (idInput.isEmpty() || nameInput.isEmpty() || specialistInput.isEmpty() ||
                workTimeInput.isEmpty() || qualificationInput.isEmpty() || roomInput.isEmpty()) {
                content.getChildren().add(new Text("Error: All fields must be filled in."));
                return;
            }

            try {
                this.id = idInput;
                this.name = nameInput;
                this.specialist = specialistInput;
                this.workTime = workTimeInput;
                this.qualification = qualificationInput;
                this.room = Integer.parseInt(roomInput);

                // Check for duplicate ID
                if (isDuplicate(doctors)) {
                    content.getChildren().add(new Text("Error: Doctor with this ID already exists."));
                    return;
                }

                // Output to file using try-with-resources
                try (FileWriter fw = new FileWriter("Doctor.txt", true);
                     PrintWriter outputFile = new PrintWriter(fw)) {

                    outputFile.println(id);
                    outputFile.println(name);
                    outputFile.println(specialist);
                    outputFile.println(workTime);
                    outputFile.println(qualification);
                    outputFile.println(room);
                    outputFile.println(""); // Adding a blank line for separation

                } catch (IOException e1) {
                    e1.printStackTrace();
                    content.getChildren().add(new Text("Error: Unable to write to file."));
                    return;
                }

                // Add the doctor to the list and display success message
                doctors.add(this);
                content.getChildren().add(new Text("Added successfully!"));

            } catch (NumberFormatException ex) {
                content.getChildren().add(new Text("Error: Room number must be an integer."));
            }
        });

        // Layout setup
        HBox rowA = new HBox(ID, txtA);
        HBox rowB = new HBox(Name, txtB);
        HBox rowC = new HBox(SP, txtC);
        HBox rowD = new HBox(WT, txtD);
        HBox rowE = new HBox(QL, txtE);
        HBox rowF = new HBox(Room, txtF);

        content.getChildren().addAll(object, new Text(""), rowA, rowB, rowC, rowD, rowE, rowF, submitBtn);
        content.setSpacing(10);
        rowA.setAlignment(Pos.CENTER);
        rowB.setAlignment(Pos.CENTER);
        rowC.setAlignment(Pos.CENTER);
        rowD.setAlignment(Pos.CENTER);
        rowE.setAlignment(Pos.CENTER);
        rowF.setAlignment(Pos.CENTER);
        content.setAlignment(Pos.CENTER);

        return content;
    }

    // Method to show doctor info in a GridPane
    public GridPane showDoctorInfo(GridPane pane, int row) {
        pane.add(new Text(id), 0, row);
        pane.add(new Text(name), 1, row);
        pane.add(new Text(specialist), 2, row);
        pane.add(new Text(workTime), 3, row);
        pane.add(new Text(qualification), 4, row);
        pane.add(new Text(Integer.toString(room)), 5, row);
        return pane;
    }
}