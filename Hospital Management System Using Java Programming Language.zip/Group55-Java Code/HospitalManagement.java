import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class HospitalManagement extends Application{
	
	ArrayList<Doctor> doctors = new ArrayList<Doctor>();
	ArrayList<Patient> patients = new ArrayList<Patient>();
	ArrayList<Lab> laboratories = new ArrayList<Lab>();
	ArrayList<Facility> facilities = new ArrayList<Facility>();
	ArrayList<Medicine> medicines = new ArrayList<Medicine>();
	ArrayList<Staff> staffs = new ArrayList<Staff>();
	//ArrayList<Building> buildings = new ArrayList<Building>();
	//= Doctor/Patient/Lab/Facility/Medical/Staff
	String objectName = "";
	BorderPane pane = new BorderPane();
	
	private void initializeData() {
		// TODO Auto-generated method stub
		doctors.add(new Doctor("973", "Richard Ting Li Zeng", "Cardiologist", "9AM-5PM", "MD", 101));
		doctors.add(new Doctor("891", "Kong Wei Hao", "Neurologist", "10AM-4PM", "MD", 102));
		doctors.add(new Doctor("003", "Charlie", "Pediatrician", "8AM-2PM", "MD", 103));
		
		patients.add(new Patient("P001", "John", "Flu", "Male", "Admitted", 30));
		patients.add(new Patient("P002", "Jane", "Cold", "Female", "Discharged", 25));
		patients.add(new Patient("P003", "Mike", "Asthma", "Male", "Admitted", 40));
		
		medicines.add(new Medicine("Paracetamol", "XYZ Pharma", "2025-12-31", 50, 200));
		medicines.add(new Medicine("Ibuprofen", "ABC Pharma", "2026-06-30", 75, 150));
		medicines.add(new Medicine("Amoxicillin", "DEF Pharma", "2027-03-31", 100, 100));
		
		laboratories.add(new Lab("x-ray", 500));
		laboratories.add(new Lab("Blood Test", 300));
		laboratories.add(new Lab("MRI", 1500));
		
		facilities.add(new Facility("Emergency Room"));
		facilities.add(new Facility("ICU"));
		facilities.add(new Facility("Pharmacy"));
		
		staffs.add(new Staff("S001", "Alice", "Nurse", "Female",50000));
		staffs.add(new Staff("S002", "Bob", "Technician", "Male", 40000));
		staffs.add(new Staff("S003", "Charlie", "Receptionist","Male", 30000));
	}

	
	@Override
	public void start(Stage primaryStage) {
		
		initializeData();
			
		//ReadFile
		try {
			readFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	
		//Welcome Msg
		Text welcomeMsg = new Text("Welcome to the HMS");
        welcomeMsg.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 30));
        welcomeMsg.setFill(Color.DARKBLUE);
        
        // Get current date and time
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);

        // Create text for date and time
        Text dateTimeMsg = new Text(" " + formattedDateTime);
        dateTimeMsg.setFont(Font.font("Courier", FontWeight.NORMAL, FontPosture.REGULAR, 20));
        dateTimeMsg.setFill(Color.DARKBLUE);

        // Create VBox for header
        VBox header = new VBox();
        header.setAlignment(Pos.CENTER);
        header.getChildren().addAll(welcomeMsg, dateTimeMsg);

        // Set header to the top of the BorderPane
        pane.setTop(header);

        // Display Menu (assumed to be defined in your code)
        displayMenu();
		
		Scene scene = new Scene(pane,800,600);
		primaryStage.setTitle("Hospital Management System");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	//Main Menu
	public void displayMenu(){

		
		Button docBtn = new Button("Doctors");
		docBtn.setPrefWidth(150);
		docBtn.setOnAction(e->{	
			objectName = "Doctor";
			actionMenu(displayDoctorRecord());
		});
		
		Button patientBtn = new Button("Patients");
		patientBtn.setPrefWidth(150);
		patientBtn.setOnAction(e->{
			objectName = "Patient";
			actionMenu(displayPatientRecord());
		});
		
		Button staffBtn = new Button("Staff");
		staffBtn.setPrefWidth(150);
		staffBtn.setOnAction(e->{
			objectName = "Staff";
			actionMenu(displayStaffRecord());
		});
		
		Button medBtn = new Button("Medicine");
		medBtn.setPrefWidth(150);
		medBtn.setOnAction(e->{	
			objectName = "Medicine";
			actionMenu(displayMedicineRecord());
		});
		
		Button labBtn = new Button("Lab");
		labBtn.setPrefWidth(150);
		labBtn.setOnAction(e->{	
			objectName = "Lab";
			actionMenu(displayLabRecord());
		});
		
		Button facBtn = new Button("Facility");
		facBtn.setPrefWidth(150);
		facBtn.setOnAction(e->{	
			objectName = "Facility";
			actionMenu(displayFacilityRecord());
		});

		Button exitBtn = new Button ("Exit");
		exitBtn.setPrefWidth(150);
		exitBtn.setOnAction(e->{
			System.exit(0);
		});
		
		VBox content = new VBox(6);
		content.getChildren().addAll(docBtn, patientBtn, staffBtn, medBtn, labBtn, facBtn, exitBtn);
		content.setAlignment(Pos.CENTER);
		content.setSpacing(10);
		pane.setCenter(content);
	}
	
	//show add, draw, main menu
	public void actionMenu(VBox content) {
		
		Button addBtn = new Button("Add New Entry");
		addBtn.setPrefWidth(150);
		addBtn.setOnAction(e->{
			if(objectName.equals("Doctor")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					doctorMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}
			else if(objectName.equals("Patient")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					patientMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}

			else if(objectName.equals("Staff")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					staffMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}
			else if(objectName.equals("Medicine")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					medicineMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}
			else if(objectName.equals("Lab")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					labMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}
			else if(objectName.equals("Facility")) {
				//0 means no action, 1 means add, 2 means draw
				try {
					facilityMenu(1);
				}
				catch (IOException ex){
					System.out.println("Invalid file ouput");
				}
			}
		});
		
		Button drawBtn = new Button("Delete An Entry");
		drawBtn.setPrefWidth(150);
		drawBtn.setOnAction(e->{
			if(objectName.equals("Doctor")) {
				try {
					doctorMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			else if(objectName.equals("Patient")) {
				try {
					patientMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			else if(objectName.equals("Staff")) {
				try {
					staffMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			else if(objectName.equals("Medicine")) {
				try {
					medicineMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			else if(objectName.equals("Lab")) {
				try {
					labMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			else if(objectName.equals("Facility")) {
				try {
					facilityMenu(2);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		//back to main menu
		Button mainBtn = new Button("Main Menu");
		mainBtn.setPrefWidth(150);
		mainBtn.setOnAction(e->{
			displayMenu();
		});
		

		content.setAlignment(Pos.CENTER);
		content.setSpacing(10);
		content.getChildren().addAll(addBtn,drawBtn,mainBtn);
		pane.setCenter(content);
	}
	
	//doctor
	//0 means no action, 1 means add, 2 means draw
	public void doctorMenu(int action) throws IOException {
		
		if(action == 1)
		{
			Doctor newDoctor = new Doctor();
			//Previous button
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayDoctorRecord());
			});
			prevBtn.setPrefWidth(150);
			VBox content = new VBox();
			content.setAlignment(Pos.CENTER);
			content.setSpacing(10);
			content.getChildren().addAll(newDoctor.newDoctor(doctors),prevBtn);
			pane.setCenter(content);
		}
		else if(action == 2)
		{
			Label instruction = new Label("Select an ID:");
			TextField inputId = new TextField();
			inputId.setPrefWidth(100);
			HBox rowA = new HBox();
			rowA.setSpacing(20);
			rowA.getChildren().addAll(instruction,inputId);
			rowA.setAlignment(Pos.CENTER);
			Button drawBtn = new Button("Delete");
			drawBtn.setOnAction(e->{
				String drawId = inputId.getText();
				for(int i = 0; i < doctors.size(); i++)
				{
					if(doctors.get(i).getId().equals(drawId))
					{
						doctors.remove(i);
						try {
							outputFile();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						break;
					}
				}
				actionMenu(displayDoctorRecord());
			});
			drawBtn.setAlignment(Pos.CENTER);
			
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayDoctorRecord());
			});
			VBox content = new VBox();
			prevBtn.setPrefWidth(150);
			drawBtn.setPrefWidth(150);
			content.getChildren().addAll(displayDoctorRecord(),rowA,drawBtn, prevBtn);
			content.setSpacing(10);
			content.setAlignment(Pos.CENTER);
			pane.setCenter(content);
		
		}
	}
	
		
	public VBox displayDoctorRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Doctor");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 38));
		
		//Header of table record
		Text headerA = new Text("Id");
		Text headerB = new Text("Name");
		Text headerC = new Text("Specialist");
		Text headerD = new Text("Work Time");
		Text headerE = new Text("Qualification");
		Text headerF = new Text("Room No");
		headerA.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerB.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerC.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerD.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerE.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerF.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,18));
		headerA.setStroke(Color.LIGHTSKYBLUE);
		headerB.setStroke(Color.LIGHTSKYBLUE);
		headerC.setStroke(Color.LIGHTSKYBLUE);
		headerD.setStroke(Color.LIGHTSKYBLUE);
		headerE.setStroke(Color.LIGHTSKYBLUE);
		headerF.setStroke(Color.LIGHTSKYBLUE);
		record.add(headerA, 0, 0);
		record.add(headerB, 1, 0);
		record.add(headerC, 2, 0);
		record.add(headerD, 3, 0);
		record.add(headerE, 4, 0);
		record.add(headerF, 5, 0);
		
		for(int col = 0; col < 5; col++) {
			record.getColumnConstraints().add(new ColumnConstraints(150));
		}

		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));

		if(doctors.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < doctors.size(); i++)
			{
				doctors.get(i).showDoctorInfo(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}
	
	//patient
	//0 means no action, 1 means add, 2 means draw
	public void patientMenu(int action) throws IOException {
		
		if(action == 1)
		{
			Patient newPatient = new Patient();
			//Previous button
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayPatientRecord());
			});
			prevBtn.setPrefWidth(150);
			VBox content = new VBox();
			content.setAlignment(Pos.CENTER);
			content.setSpacing(10);
			content.getChildren().addAll(newPatient.newPatient(patients),prevBtn);
			pane.setCenter(content);
		}
		else if(action == 2)
		{
			Label instruction = new Label("Select an ID:");
			TextField inputId = new TextField();
			inputId.setPrefWidth(100);
			HBox rowA = new HBox();
			rowA.setSpacing(20);
			rowA.getChildren().addAll(instruction,inputId);
			rowA.setAlignment(Pos.CENTER);
			Button drawBtn = new Button("Delete");
			drawBtn.setOnAction(e->{
				String drawId = inputId.getText();
				for(int i = 0; i < patients.size(); i++)
				{
					if(patients.get(i).getId().equals(drawId))
					{
						patients.remove(i);
						try {
							outputFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						break;
					}
				}
				actionMenu(displayPatientRecord());
			});
			drawBtn.setAlignment(Pos.CENTER);
			
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayPatientRecord());
			});
			VBox content = new VBox();
			prevBtn.setPrefWidth(150);
			drawBtn.setPrefWidth(150);
			content.getChildren().addAll(displayPatientRecord(),rowA,drawBtn, prevBtn);
			content.setSpacing(10);
			content.setAlignment(Pos.CENTER);
			pane.setCenter(content);
		
		}
		
	}
		
	public VBox displayPatientRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Patient");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 40));
		
		//Header of table record
		Text headerA = new Text("Id");
		Text headerB = new Text("Name");
		Text headerC = new Text("Disease");
		Text headerD = new Text("Sex");
		Text headerE = new Text("Admit Status");
		Text headerF = new Text("Age");
		headerA.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerB.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerC.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerD.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerE.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerF.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerA.setStroke(Color.LIGHTSKYBLUE);
		headerB.setStroke(Color.LIGHTSKYBLUE);
		headerC.setStroke(Color.LIGHTSKYBLUE);
		headerD.setStroke(Color.LIGHTSKYBLUE);
		headerE.setStroke(Color.LIGHTSKYBLUE);
		headerF.setStroke(Color.LIGHTSKYBLUE);
		record.add(headerA, 0, 0);
		record.add(headerB, 1, 0);
		record.add(headerC, 2, 0);
		record.add(headerD, 3, 0);
		record.add(headerE, 4, 0);
		record.add(headerF, 5, 0);
		
		for(int col = 0; col < 5; col++) {
			record.getColumnConstraints().add(new ColumnConstraints(150));
		}

		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));

		if(patients.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < patients.size(); i++)
			{
				patients.get(i).showPatientInfo(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}	
	
	
	
	//staffs
	//0 means no action, 1 means add, 2 means draw
	public void staffMenu(int action) throws IOException {
		
		if(action == 1)
		{
			Staff newStaff = new Staff();
			//Previous button
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayStaffRecord());
			});
			prevBtn.setPrefWidth(150);
			VBox content = new VBox();
			content.setAlignment(Pos.CENTER);
			content.setSpacing(10);
			content.getChildren().addAll(newStaff.newStaff(staffs),prevBtn);
			pane.setCenter(content);
		}
		else if(action == 2)
		{
			Label instruction = new Label("Select an ID:");
			TextField inputId = new TextField();
			inputId.setPrefWidth(100);
			HBox rowA = new HBox();
			rowA.setSpacing(20);
			rowA.getChildren().addAll(instruction,inputId);
			rowA.setAlignment(Pos.CENTER);
			Button drawBtn = new Button("Delete");
			drawBtn.setOnAction(e->{
				String drawId = inputId.getText();
				for(int i = 0; i < staffs.size(); i++)
				{
					if(staffs.get(i).getId().equals(drawId))
					{
						staffs.remove(i);
						try {
							outputFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						break;
					}
				}
				actionMenu(displayStaffRecord());
			});
			drawBtn.setAlignment(Pos.CENTER);
			
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayStaffRecord());
			});
			VBox content = new VBox();
			prevBtn.setPrefWidth(150);
			drawBtn.setPrefWidth(150);
			content.getChildren().addAll(displayStaffRecord(),rowA,drawBtn, prevBtn);
			content.setSpacing(10);
			content.setAlignment(Pos.CENTER);
			pane.setCenter(content);
		
		}
		
	}
		
	public VBox displayStaffRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Staff");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 40));
		
		//Header of table record
		Text headerA = new Text("Id");
		Text headerB = new Text("Name");
		Text headerC = new Text("Designation");
		Text headerD = new Text("Sex");
		Text headerE = new Text("Salary");
		headerA.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerB.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerC.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerD.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerE.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerA.setStroke(Color.LIGHTSKYBLUE);
		headerB.setStroke(Color.LIGHTSKYBLUE);
		headerC.setStroke(Color.LIGHTSKYBLUE);
		headerD.setStroke(Color.LIGHTSKYBLUE);
		headerE.setStroke(Color.LIGHTSKYBLUE);
		record.add(headerA, 0, 0);
		record.add(headerB, 1, 0);
		record.add(headerC, 2, 0);
		record.add(headerD, 3, 0);
		record.add(headerE, 4, 0);
		
		for(int col = 0; col < 4; col++) {
			record.getColumnConstraints().add(new ColumnConstraints(150));
		}

		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));

		if(staffs.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < staffs.size(); i++)
			{
				staffs.get(i).showStaffInfo(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}
	
	public void medicineMenu(int action) throws IOException {
			
			if(action == 1)
			{
				Medicine newMedicine = new Medicine();
				//Previous button
				Button prevBtn = new Button("Previous");
				prevBtn.setOnAction(e->{
					actionMenu(displayMedicineRecord());
				});
				prevBtn.setPrefWidth(150);
				VBox content = new VBox();
				content.setAlignment(Pos.CENTER);
				content.setSpacing(10);
				content.getChildren().addAll(newMedicine.newMedicine(medicines),prevBtn);
				pane.setCenter(content);
			}
			else if(action == 2)
			{
				Label instruction = new Label("Name of Medicine:");
				TextField inputName = new TextField();
				inputName.setPrefWidth(100);
				HBox rowA = new HBox();
				rowA.setSpacing(20);
				rowA.getChildren().addAll(instruction,inputName);
				rowA.setAlignment(Pos.CENTER);
				Button drawBtn = new Button("Delete");
				drawBtn.setOnAction(e->{
					String drawName = inputName.getText();
					for(int i = 0; i < medicines.size(); i++)
					{
						if(medicines.get(i).getName().equals(drawName))
						{
							medicines.remove(i);
							try {
								outputFile();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							break;
						}
					}
					actionMenu(displayMedicineRecord());
				});
				drawBtn.setAlignment(Pos.CENTER);
				
				Button prevBtn = new Button("Previous");
				prevBtn.setOnAction(e->{
					actionMenu(displayMedicineRecord());
				});
				VBox content = new VBox();
				prevBtn.setPrefWidth(150);
				drawBtn.setPrefWidth(150);
				content.getChildren().addAll(displayMedicineRecord(),rowA,drawBtn, prevBtn);
				content.setSpacing(10);
				content.setAlignment(Pos.CENTER);
				pane.setCenter(content);
			
			}
			
		}

	public VBox displayMedicineRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Medicine");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 40));
		
		//Header of table record
		Text headerA = new Text("Medicine");
		Text headerB = new Text("Manufacturer");
		Text headerC = new Text("Expire Date");
		Text headerD = new Text("Cost per Unit");
		Text headerE = new Text("Number");
		headerA.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerB.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerC.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerD.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerE.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerA.setStroke(Color.LIGHTSKYBLUE);
		headerB.setStroke(Color.LIGHTSKYBLUE);
		headerC.setStroke(Color.LIGHTSKYBLUE);
		headerD.setStroke(Color.LIGHTSKYBLUE);
		headerE.setStroke(Color.LIGHTSKYBLUE);
		record.add(headerA, 0, 0);
		record.add(headerB, 1, 0);
		record.add(headerC, 2, 0);
		record.add(headerD, 3, 0);
		record.add(headerE, 4, 0);
		
		for(int col = 0; col < 4; col++) {
			record.getColumnConstraints().add(new ColumnConstraints(150));
		}
	
		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));
	
		if(medicines.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < medicines.size(); i++)
			{
				medicines.get(i).findMedicine(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}
	
	public void labMenu(int action) throws IOException {
		
		if(action == 1)
		{
			Lab newLab = new Lab();
			//Previous button
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayLabRecord());
			});
			prevBtn.setPrefWidth(150);
			VBox content = new VBox();
			content.setAlignment(Pos.CENTER);
			content.setSpacing(10);
			content.getChildren().addAll(newLab.newLab(laboratories),prevBtn);
			pane.setCenter(content);
		}
		else if(action == 2)
		{
			Label instruction = new Label("Name of Lab:");
			TextField inputLab = new TextField();
			inputLab.setPrefWidth(100);
			HBox rowA = new HBox();
			rowA.setSpacing(20);
			rowA.getChildren().addAll(instruction,inputLab);
			rowA.setAlignment(Pos.CENTER);
			Button drawBtn = new Button("Delete");
			drawBtn.setOnAction(e->{
				String drawLab = inputLab.getText();
				for(int i = 0; i < laboratories.size(); i++)
				{
					if(laboratories.get(i).getLab().equals(drawLab))
					{
						laboratories.remove(i);
						try {
							outputFile();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						break;
					}
				}
				actionMenu(displayLabRecord());
			});
			drawBtn.setAlignment(Pos.CENTER);
			
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayLabRecord());
			});
			VBox content = new VBox();
			prevBtn.setPrefWidth(150);
			drawBtn.setPrefWidth(150);
			content.getChildren().addAll(displayLabRecord(),rowA,drawBtn, prevBtn);
			content.setSpacing(10);
			content.setAlignment(Pos.CENTER);
			pane.setCenter(content);
		
		}
		
	}

	public VBox displayLabRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Lab");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 40));
		
		//Header of table record
		Text headerA = new Text("Name of Lab:");
		Text headerB = new Text("Cost per Unit");
		
		headerA.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		headerB.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		
		headerA.setStroke(Color.LIGHTSKYBLUE);
		headerB.setStroke(Color.LIGHTSKYBLUE);
	
		record.add(headerA, 0, 0);
		record.add(headerB, 1, 0);
	
		for(int col = 0; col < 2; col++) {
			record.getColumnConstraints().add(new ColumnConstraints(150));
		}
	
		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));
	
		if(laboratories.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < laboratories.size(); i++)
			{
				laboratories.get(i).labList(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}
	
	public void facilityMenu(int action) throws IOException {
		
		if(action == 1)
		{
			Facility newFacility = new Facility();
			//Previous button
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayFacilityRecord());
			});
			prevBtn.setPrefWidth(150);
			VBox content = new VBox();
			content.setAlignment(Pos.CENTER);
			content.setSpacing(10);
			content.getChildren().addAll(newFacility.newFacility(facilities),prevBtn);
			pane.setCenter(content);
		}
		else if(action == 2)
		{
			Label instruction = new Label("Facility:");
			TextField inputFacility = new TextField();
			inputFacility.setPrefWidth(100);
			HBox rowA = new HBox();
			rowA.setSpacing(20);
			rowA.getChildren().addAll(instruction,inputFacility);
			rowA.setAlignment(Pos.CENTER);
			Button drawBtn = new Button("Delete");
			drawBtn.setOnAction(e->{
				String drawLab = inputFacility.getText();
				for(int i = 0; i < facilities.size(); i++)
				{
					if(facilities.get(i).getFacility().equals(drawLab))
					{
						facilities.remove(i);
						try {
							outputFile();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						break;
					}
				}
				actionMenu(displayFacilityRecord());
			});
			drawBtn.setAlignment(Pos.CENTER);
			
			Button prevBtn = new Button("Previous");
			prevBtn.setOnAction(e->{
				actionMenu(displayFacilityRecord());
			});
			VBox content = new VBox();
			prevBtn.setPrefWidth(150);
			drawBtn.setPrefWidth(150);
			content.getChildren().addAll(displayFacilityRecord(),rowA,drawBtn, prevBtn);
			content.setSpacing(10);
			content.setAlignment(Pos.CENTER);
			pane.setCenter(content);
		
		}
		
	}
	
	public VBox displayFacilityRecord() {
		GridPane record = new GridPane();
		Text object = new Text("Facility");
		object.setFont(Font.font("Times New Roman",FontWeight.BOLD, FontPosture.REGULAR, 40));
		
		//Header of table record
		Text header = new Text("Facility:");
		header.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.REGULAR,20));
		header.setStroke(Color.LIGHTSKYBLUE);
		record.add(header, 0, 0);
		record.getColumnConstraints().add(new ColumnConstraints(150));
	
		VBox content = new VBox();
		content.getChildren().addAll(object,new Text(""));
	
		if(facilities.size() == 0)
		{
			content.getChildren().add(record);
			content.getChildren().add(new Text("No record"));
		}
		else 
		{
			for(int i = 0; i < facilities.size(); i++)
			{
				facilities.get(i).showFacility(record, i+1);
			}
			content.getChildren().add(record);
		}
		
		content.getChildren().add(new Text(""));
		content.setSpacing(10);
		content.setAlignment(Pos.CENTER);
		record.setAlignment(Pos.CENTER);
		return content;
	}
	
	//Read File
	public void readFile() throws IOException{
		//read Doctor
		 File file = new File("Doctor.txt");
	        if (file.exists()) {
	            Scanner inputFile = new Scanner(file);
	            while (inputFile.hasNext()) {
	                String txt = inputFile.nextLine();
	                if (txt.length() != 0) {
	                    Doctor doctor = new Doctor();
	                    doctor.setId(txt);
	                    doctor.setName(inputFile.nextLine());
	                    doctor.setSpecialist(inputFile.nextLine());
	                    doctor.setWorkTime(inputFile.nextLine());
	                    doctor.setQualification(inputFile.nextLine());
	                    doctor.setRoom(Integer.parseInt(inputFile.nextLine()));
	                    doctors.add(doctor);
	                }
	            }
	            inputFile.close();
	        }

		
		//read Patient
		file = new File("Patient.txt");
		if(file.exists()) {
			Scanner inputFile = new Scanner(file);
			while(inputFile.hasNext()) {
				String txt = inputFile.nextLine();
				Patient patient = new Patient();
				if(txt.length() != 0)
				{
					patient.setId(txt);
					patient.setName(inputFile.nextLine());
					patient.setDisease(inputFile.nextLine());
					patient.setSex(inputFile.nextLine());
					patient.setAdmitStatus(inputFile.nextLine());
					patient.setAge(Integer.parseInt(inputFile.nextLine()));
					patients.add(patient);
				}
			}
			inputFile.close();
		}
		
		//read staffs
		file = new File("Staff.txt");
		if(file.exists()) {
			Scanner inputFile = new Scanner(file);
			while(inputFile.hasNext()) {
				String txt = inputFile.nextLine();
				Staff staff = new Staff();
				if(txt.length() != 0)
				{
					staff.setId(txt);
					staff.setName(inputFile.nextLine());
					staff.setDesignation(inputFile.nextLine());
					staff.setSex(inputFile.nextLine());
					staff.setSalary(Integer.parseInt(inputFile.nextLine()));
					staffs.add(staff);
				}
			}
			inputFile.close();
		}
		
		//read medicines
		file = new File("Medicine.txt");
		if(file.exists()) {
			Scanner inputFile = new Scanner(file);
			while(inputFile.hasNext()) {
				String txt = inputFile.nextLine();
				Medicine medicine = new Medicine();
				if(txt.length() != 0)
				{
					medicine.setName(txt);
					medicine.setManufacturer(inputFile.nextLine());
					medicine.setExpiryDate(inputFile.nextLine());
					medicine.setCost(Integer.parseInt(inputFile.nextLine()));
					medicine.setCount(Integer.parseInt(inputFile.nextLine()));
					medicines.add(medicine);
				}
			}
			inputFile.close();
		}
		
		//read labs
		file = new File("Lab.txt");
		if(file.exists()) {
			Scanner inputFile = new Scanner(file);
			while(inputFile.hasNext()) {
				String txt = inputFile.nextLine();
			Lab lab = new Lab();
				if(txt.length() != 0)
				{
					lab.setLab(txt);
					lab.setCost(Integer.parseInt(inputFile.nextLine()));
					laboratories.add(lab);
				}
			}
			inputFile.close();
		}
		
		//read facilities
		file = new File("Facility.txt");
		if(file.exists()) {
			Scanner inputFile = new Scanner(file);
			while(inputFile.hasNext()) {
				String txt = inputFile.nextLine();
			Facility facility = new Facility();
				if(txt.length() != 0)
				{
					facility.setFacility(txt);
					facilities.add(facility);
				}
			}
			inputFile.close();
		}
	}
	
	
	
	//Overwrite File
	public void outputFile()throws IOException{
		PrintWriter outputFile = new PrintWriter(objectName + ".txt");
        if (objectName.equals("Doctor")) {
            for (Doctor doctor : doctors) {
                outputFile.println(doctor.getId());
                outputFile.println(doctor.getName());
                outputFile.println(doctor.getSpecialist());
                outputFile.println(doctor.getWorkTime());
                outputFile.println(doctor.getQualification());
                outputFile.println(Integer.toString(doctor.getRoom()));
            }
        }
		else if(objectName == "Patient") {
			for(Patient patient : patients) {
				outputFile.println(patient.getId());
				outputFile.println(patient.getName());
				outputFile.println(patient.getDisease());
				outputFile.println(patient.getSex());
				outputFile.println(patient.getAdmitStatus());
				outputFile.println(Integer.toString(patient.getAge()));
			}
		}
		else if(objectName == "Staff") {
			for(Staff staff : staffs) {
				outputFile.println(staff.getId());
				outputFile.println(staff.getName());
				outputFile.println(staff.getDesignation());
				outputFile.println(staff.getSex());
				outputFile.println(Integer.toString(staff.getSalary()));
			}
		}
	
		else if(objectName == "Medicine") {
			for(Medicine medicine : medicines) {
				outputFile.println(medicine.getName());
				outputFile.println(medicine.getManufacturer());
				outputFile.println(medicine.getExpiryDate());
				outputFile.println(Integer.toString(medicine.getCost()));
				outputFile.println(Integer.toString(medicine.getCount()));
			}
		}
		
		else if(objectName == "Lab") {
			for(Lab lab : laboratories) {
				outputFile.println(lab.getLab());
				outputFile.println(Integer.toString(lab.getCost()));
			}
		}
		
		else if(objectName == "Facility") {
			for(Facility facility : facilities) {
				outputFile.println(facility.getFacility());
			}
		}
		
	outputFile.close();
}	
	
	public static void main(String[] args) {
		launch(args);
	}

}
