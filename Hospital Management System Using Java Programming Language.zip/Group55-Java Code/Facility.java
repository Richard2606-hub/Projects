import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Facility {
	private String facility;
	
	public Facility() {
		
	}
	
	public Facility(String facility) {
		this.facility = facility;
	}
	
	 private static final int MAX_FACILITIES = 20;
	    private static Facility[] facArray = new Facility[MAX_FACILITIES];
	    private static int facilityCount = 0;

	    public static void addFacility(Facility facility) {
	        if (facilityCount < MAX_FACILITIES) {
	            facArray[facilityCount] = facility;
	            facilityCount++;
	        } else {
	            // Handle the case when the array is full
	            System.out.println("Maximum number of doctors reached.");
	        }
	    }

	    public static Facility getFacility(int index) {
	        if (index >= 0 && index < facilityCount) {
	            return facArray[index];
	        } else {
	            // Handle the case when the index is out of bounds
	            return null;
	        }
	    }
	
	public String getFacility() {
		return facility;
	}
	
	public void setFacility(String facility) {
		this.facility = facility;
	}
	
	 private boolean isDuplicate(ArrayList<Facility> facilities) {
	        for (Facility facility : facilities) {
	            if (facility.getFacility().equals(this.facility)) {
	                return true;
	            }
	        }
	        return false;
	    }
	
	 public VBox newFacility(ArrayList<Facility> facilities) {
	        Text object = new Text("Facility");
	        object.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));

	        VBox content = new VBox();
	        Label Facility = new Label("Facility name: ");
	        TextField txtA = new TextField();
	        Facility.setPrefWidth(250);

	   

	        Button submitBtn = new Button("Submit");
	        submitBtn.setPrefWidth(150);
	        submitBtn.setOnAction(e -> {
	            String facilityInput = txtA.getText().trim();

	            // Validate input
	            if (facilityInput.isEmpty()) {
	                content.getChildren().add(new Text("Error: Facility name must be filled in."));
	                return;
	            }

	            try {
	                this.facility = facilityInput;

	                // Check for duplicate ID
	                if (isDuplicate(facilities)) {
	                    content.getChildren().add(new Text("Error: Facility already exists."));
	                    return;
	                }

	                // Output to file using try-with-resources
	                try (FileWriter fw = new FileWriter("Facility.txt", true);
	                     PrintWriter outputFile = new PrintWriter(fw)) {

	                    outputFile.println(facility);
	                    outputFile.println(""); // Adding a blank line for separation

	                } catch (IOException e1) {
	                    e1.printStackTrace();
	                    content.getChildren().add(new Text("Error: Unable to write to file."));
	                    return;
	                }

	                // Add the staff to the list and display success message
	                facilities.add(this);
	                content.getChildren().add(new Text("Added successfully!"));

	            } catch (NumberFormatException ex) {
	                content.getChildren().add(new Text("Error: Salary must be an integer."));
	            }
	        });

	        // Layout setup
	        HBox rowA = new HBox(Facility, txtA);

	        content.getChildren().addAll(object, new Text(""), rowA, submitBtn);
	        content.setSpacing(10);
	        rowA.setAlignment(Pos.CENTER);
	        content.setAlignment(Pos.CENTER);

	        return content;
	    }
	 
	 public GridPane showFacility(GridPane pane, int row) {
	        pane.add(new Text(facility) ,0, row);
	        return pane;
	    }
}
