import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Staff {
    private String id, name, designation, sex;
    private int salary;
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }
    public int getSalary() { return salary; }
    public void setSalary(int salary) { this.salary = salary; }

    public Staff() {
		
	}
	
	public Staff(String id, String name, String designation, String sex, int salary) {
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.sex = sex;
		this.salary = salary;
	}
    
    // Method to check if the staff already exists
    private boolean isDuplicate(ArrayList<Staff> staffs) {
        for (Staff staff : staffs) {
            if (staff.getId().equals(this.id)) {
                return true;
            }
        }
        return false;
    }

    // Method to create the new staff form
    public VBox newStaff(ArrayList<Staff> staffs) {
        Text object = new Text("Staff");
        object.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 40));

        VBox content = new VBox();
        Label ID = new Label("Enter ID: ");
        TextField txtA = new TextField();
        ID.setPrefWidth(250);

        Label Name = new Label("Enter Name: ");
        TextField txtB = new TextField();
        Name.setPrefWidth(250);

        Label DS = new Label("Enter Designation: ");
        TextField txtC = new TextField();
        DS.setPrefWidth(250);

        Label Sex = new Label("Enter Sex: ");
        TextField txtD = new TextField();
        Sex.setPrefWidth(250);

        Label SL = new Label("Enter Salary: ");
        TextField txtE = new TextField();
        SL.setPrefWidth(250);

        Button submitBtn = new Button("Submit");
        submitBtn.setPrefWidth(150);
        submitBtn.setOnAction(e -> {
            String idInput = txtA.getText().trim();
            String nameInput = txtB.getText().trim();
            String designationInput = txtC.getText().trim();
            String sexInput = txtD.getText().trim();
            String salaryInput = txtE.getText().trim();

            // Validate input
            if (idInput.isEmpty() || nameInput.isEmpty() || designationInput.isEmpty() ||
                sexInput.isEmpty() || salaryInput.isEmpty()) {
                content.getChildren().add(new Text("Error: All fields must be filled in."));
                return;
            }

            try {
                this.id = idInput;
                this.name = nameInput;
                this.designation = designationInput;
                this.sex = sexInput;
                this.salary = Integer.parseInt(salaryInput);

                // Check for duplicate ID
                if (isDuplicate(staffs)) {
                    content.getChildren().add(new Text("Error: Staff with this ID already exists."));
                    return;
                }

                // Output to file using try-with-resources
                try (FileWriter fw = new FileWriter("Staff.txt", true);
                     PrintWriter outputFile = new PrintWriter(fw)) {

                    outputFile.println(id);
                    outputFile.println(name);
                    outputFile.println(designation);
                    outputFile.println(sex);
                    outputFile.println(Integer.toString(salary));
                    outputFile.println(""); // Adding a blank line for separation

                } catch (IOException e1) {
                    e1.printStackTrace();
                    content.getChildren().add(new Text("Error: Unable to write to file."));
                    return;
                }

                // Add the staff to the list and display success message
                staffs.add(this);
                content.getChildren().add(new Text("Added successfully!"));

            } catch (NumberFormatException ex) {
                content.getChildren().add(new Text("Error: Salary must be an integer."));
            }
        });

        // Layout setup
        HBox rowA = new HBox(ID, txtA);
        HBox rowB = new HBox(Name, txtB);
        HBox rowC = new HBox(DS, txtC);
        HBox rowD = new HBox(Sex, txtD);
        HBox rowE = new HBox(SL, txtE);

        content.getChildren().addAll(object, new Text(""), rowA, rowB, rowC, rowD, rowE, submitBtn);
        content.setSpacing(10);
        rowA.setAlignment(Pos.CENTER);
        rowB.setAlignment(Pos.CENTER);
        rowC.setAlignment(Pos.CENTER);
        rowD.setAlignment(Pos.CENTER);
        rowE.setAlignment(Pos.CENTER);
        content.setAlignment(Pos.CENTER);

        return content;
    }

    // Method to show staff info in a GridPane
    public GridPane showStaffInfo(GridPane pane, int row) {
        pane.add(new Text(id), 0, row);
        pane.add(new Text(name), 1, row);
        pane.add(new Text(designation), 2, row);
        pane.add(new Text(sex), 3, row);
        pane.add(new Text(Integer.toString(salary)), 4, row);
        return pane;
    }
}
